
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd"> 
<html> 
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"> 
 
<title>Under Construction</title> 
</head> 
<body> 
<br><br><br><br><br><br><br> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center"> 
   <tr> 
      <td align="center"> 
      <img src="error.png" border="0"> 
      <h1 style="margin:0;padding:0;font-family: trebuchet ms;">Welcome to Gurukul</small> 
      </h1> 
      </td> 
      </tr> 
    </table> 
  </body> 
</html> 

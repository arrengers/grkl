<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Gurukul_model extends CI_Model {
	
	public function __construct() {
		parent::__construct();
		
		//load database library
		//$this->load->database();
	}

	/*
	 * Fetch user data
	 */
	function getCourse($id = ""){
	    
	    if(!empty($id)){
	        $query = $this->db->get_where('class', array('class_id' => $id));
	        //echo $this->db->last_query();
	        return $query->row_array();
	    }else{
	        $query = $this->db->get('class');
	        return $query->result_array();
	    }
	}
	
	/*
	 * Function to update cources
	 */
	function updateCourse($data= ""){
	    $this->db->set('fee', $data['course_fee']);
	    $this->db->where('class_id',$data['class_id']);
	    $update = $this->db->update('class'); // gives UPDATE coursesSET course_name= $course_name WHERE course_id= $course_id
	    return $this->db->affected_rows();
	}
	
	/*
	 * Function to get student details
	 */
	
	function searchStudent($data=""){
	    if(!empty($data)){
	        $student =($data['student_id']!='')? "WHERE s.student_code LIKE '%".$this->db->escape_like_str($data['student_id'])."%'":'';
	        //$name = ($data['name']!='')? (($student !='') ? "OR s.name LIKE '%". $this->db->escape_like_str($data['name'])."%'":" where s.name LIKE '%". $this->db->escape_like_str($data['name'])."%'"):'';
	        $name ='';
	        $class = ($data['class']!='')? (($student !='' || $name !='') ? "OR s.class LIKE '%". $this->db->escape_like_str($data['class'])."%'":"WHERE s.class LIKE '%". $this->db->escape_like_str($data['class'])."%'"):'';
	        
            $sql = "SELECT *, s.student_id as student_id FROM students s LEFT JOIN student_address sa ON s.student_id = sa.student_id $student $name $class";
	            
	        $query = $this->db->query($sql);
	        //echo $this->db->last_query();exit();
	        return $query->row_array();
	    }
	    return FALSE;
	    
	}
	
	
	/*
	 * Function to calculate total due student fee
	 */

	function studentFeeDue($student_id){
	    if(!empty($student_id)){
	        $this->db->select_sum('amount_paid');
	        $this->db->select('amount_paid');
	        $this->db->from('fee_payment_detail');
	        $this->db->where('student_id',$student_id);
	        $this->db->order_by('amount_paid desc');
	        return $this->db->get();
	        //$query = $this->db->get_where('fee_payment_detail', array('student_id' => $id));
	        //return $query->row_array();
	    }
        return FALSE;
	    
	}
	
	/*
	 * function to submit student fee
	 */
	
	function submitStudentFee($data){
	    $data['payment_date'] = date("Y-m-d H:i:s");
	    $update = $this->db->update('fee_payment_detail', $data, array('student_id'=>$id));
        return $update?true:false;
	}
		
	
	
	/*
	 * Function to get student details by id
	 */
	
	function getStudentDetails($student_code=""){
	    if(!empty($student_code)){
	        $sql = "SELECT s.*,c.name as class_name FROM students s 
                        LEFT JOIN student_address sa ON s.student_id = sa.student_id
                        LEFT JOIN class c ON c.class_id = s.class
                    WHERE s.student_code = ? ORDER BY s.academicyear DESC LIMIT 1 ";
	        $query = $this->db->query($sql,array($student_code));
	        return $query->row_array();
	    }else{
	        $sql = "SELECT s.*,c.name as class_name FROM students s 
                        LEFT JOIN student_address sa ON s.student_id = sa.student_id
                        LEFT JOIN class c ON c.class_id = s.class ";
	        $query = $this->db->query($sql);
	        return $query->result_array();
	    }
	}

	/*
	 * Function to get student details by id
	 */
	
	function getStudentDetailsByClass($student_id="",$class_id){
	    if(!empty($student_id)){
	        $sql = "SELECT s.*,c.name as class_name FROM students s
                        LEFT JOIN student_address sa ON s.student_id = sa.student_id
                        LEFT JOIN class c ON c.class_id = s.class
                    WHERE s.student_id = ? AND class = ? ";
	        $query = $this->db->query($sql,array($student_id,$class_id));
	        //echo $this->db->last_query();exit();
	        return $query->row_array();
	    }else{
	        $sql = "SELECT s.*,c.name as class_name FROM students s
                        LEFT JOIN student_address sa ON s.student_id = sa.student_id
                        LEFT JOIN class c ON c.class_id = s.class
                    WHERE class = ? ";
	        $query = $this->db->query($sql,array($class_id));
	        return $query->result_array();
	    }
	}
	
	
	/*
	 * Function to get totalFeeDue
	 */
	
	function totalFeeDue($student_code=''){
	    if(!empty($student_code)){
	        $sql = "SELECT  f.month_fee_paid_for, f.year_fee_paid_for as year, sm.name , sm.name as month_name,  f.amount_paid 
                        FROM fee_payment_detail f 
                    LEFT JOIN session_months sm ON sm.month_id = f.month_fee_paid_for 
	                    WHERE (
                                (f.year_fee_paid_for = YEAR(CURDATE()) AND f.month_fee_paid_for <= MONTH(CURDATE() - INTERVAL 3 MONTH))
                                OR (f.year_fee_paid_for < YEAR(CURDATE()) AND f.month_fee_paid_for <= 12)
                              )
                                AND f.amount_paid=0  AND f.student_code=?";
	        $query = $this->db->query($sql,array($student_code));
	        //echo $this->db->last_query();exit();
	        return $query->result_array();
	    }else {
	        return false;
	    }
	}
	
	
	/*
	 * function to get feeStructure
	 */
	
	function feeStructure($student_code){
	    $sql = "SELECT f.session_year_start as year, f.fee  FROM students s 
                    LEFT JOIN fee_structure f ON s.academicyear= f.session_year_start  
                WHERE s.student_code =? group by f.session_year_start";
	    $query = $this->db->query($sql,array($student_code));
	    $result=$query->result_array();
	    //print_r($result);
	    foreach ($result as $res){
	        $fee[$res['year']]=$res['fee'];
	    }
	    return $fee;
	}
	
	
	/*
	 * saveStudentFee($tF['month'],$tF['year'],$tF['amount_paid']);
	 */
	
	function saveStudentFee($month,$year,$amount_paid,$student_code){
	    $data = array('amount_paid'=> $amount_paid,'payment_received_by'=> $this->user_id,'payment_date' => date('Y-m-d H:i:s'));
	    
	    return $this->db->update('fee_payment_detail', $data, array('month_fee_paid_for'=>$month,'year_fee_paid_for'=>$year,'student_code' => $student_code));
	}
	
	
	/*
	 * submitStudentOtherFee($tF['month'],$tF['year'],$tF['amount_paid']);
	 */
	
	function submitStudentOtherFee($reason,$amount_paid,$student_code){
	    $data = array('amount_paid_for' => $reason,
	       'amount_paid' => $amount_paid,
	       'payment_date' => date('Y-m-d H:i:s'),
	       'payment_received_by' => $this->user_id,
	       'student_code' => $student_code);
	    return  $this->db->insert('other_fee_payment_details', $data);
	}
	

	/*
	 * function to get paied Student Details by id and date
	 */
	function getpaiedStudentDetails($student_code, $date){
	    $sql = "SELECT * FROM other_fee_payment_details WHERE student_code ='".$this->db->escape_like_str($student_code)."' AND payment_date like '%".$date."%'";
	    $query = $this->db->query($sql);
	    //echo $this->db->last_query();exit();
	    return $query->result_array();
	}
	
	/*
	 * Function to get student details by id
	 */
	
	function getTeacherDetails($teacher_id=""){
	    if(!empty($teacher_id)){
	        $sql = "SELECT * FROM teacher t WHERE t.teacher_id = '".$this->db->escape_like_str($teacher_id)."'";
	        $query = $this->db->query($sql);
	        //echo $this->db->last_query();exit();
	        return $query->row_array();
	    }else{
	        $sql = "SELECT * FROM teacher";
	        $query = $this->db->query($sql);
	        return $query->result_array();
	    }
	}
	
	
	/*
	 * function to submit Teacher Attendance
	 */
	
	function submitTeacherAttendance($teacher_id,$date,$status){
	    $data = array('teacher_id'=>$teacher_id, 'date'=>$date, 'status'=>$status);
	    
	    $sql = "SELECT * FROM teacher_attendance WHERE teacher_id = ? AND date=?";
	    $query = $this->db->query($sql,array($teacher_id,$date));
	    //echo $this->db->last_query();
	    
	    //echo $query->num_rows();exit();
	    if($query->num_rows()>0){
	        $data['updated_on'] = date("Y-m-d");
	        $data['updated_by'] = 1;
	        $update = $this->db->update('teacher_attendance', $data, array('teacher_id'=>$teacher_id));
	    }else {
	        $data['created_on'] = date("Y-m-d");
	        $data['created_by'] = 1;
	        $update = $this->db->insert('teacher_attendance', $data);
	    }
	    return $update?true:false;
	}
	
	
	/*
	 * function to submit Teacher Attendance
	 */
	
	function markStudentAttendance($student_id,$date,$status,$class_id){
	    $data = array('student_id'=>$student_id, 'date'=>$date, 'status'=>$status,'class'=>$class_id);
	    
	    $sql = "SELECT * FROM student_attendance WHERE student_id = ? AND date=?";
	    $query = $this->db->query($sql,array($student_id,$date));
	    //echo $this->db->last_query();
	    
	    //echo $query->num_rows();exit();
	    if($query->num_rows()>0){
	        $data['updated_on'] = date("Y-m-d");
	        $data['updated_by'] = 1;
	        $update = $this->db->update('student_attendance', $data, array('student_id'=>$student_id));
	    }else {
	        $data['created_on'] = date("Y-m-d");
	        $data['created_by'] = 1;
	        $update = $this->db->insert('student_attendance', $data);
	    }
	    return $update?true:false;
	}
	
	
	
	
	/*
	 * Fetch course data
	 */
	function getRows($id = ""){
		if(!empty($id)){
			$query = $this->db->get_where('courses', array('course_id' => $id));
			return $query->row_array();
		}else{
			$query = $this->db->get('courses');
			return $query->result_array();
		}
	}
	
	/*
	 * Insert user data
	 */
	/*
	public function insert($data = array()) {
		if(!array_key_exists('created', $data)){
			$data['created'] = date("Y-m-d H:i:s");
		}
		if(!array_key_exists('modified', $data)){
			$data['modified'] = date("Y-m-d H:i:s");
		}
		$insert = $this->db->insert('courses', $data);
		if($insert){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}
	*/
	/*
	 * Update user data
	 */
	
	/*
	public function update($data, $id) {
		if(!empty($data) && !empty($id)){
			if(!array_key_exists('modified', $data)){
				$data['modified'] = date("Y-m-d H:i:s");
			}
			$update = $this->db->update('courses', $data, array('course_id'=>$id));
			return $update?true:false;
		}else{
			return false;
		}
	}
	*/
	/*
	 * Delete user data
	 */
	/*
	public function delete($id){
		$delete = $this->db->delete('courses',array('course_id'=>$id));
		return $delete?true:false;
	}
	
	*/
}
?>
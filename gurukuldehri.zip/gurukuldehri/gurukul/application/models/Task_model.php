<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Task_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /*
     * Fetch task data by user_id
     */

    function getTasks($id = "", $pagination = null) {
        $sort_order = 'DESC';
        $sort_by = 'updated_date';

        if (!empty($id)) {
            $query = $this->db->select('activity_id,activity_name,activity_type,course_category,task_id,created_by,task_start_date,task_end_date,parent_task_id,details,task_status,parent_task_name')->from('task_lists')->where('user_id', $id)->get();
            $this->db->order_by($sort_by, $sort_order);
        } else {
            if ($pagination) {
                $wherePart = "";

                if ($this->session->get_userdata() && isset($this->session->get_userdata()['role'])) {
                    if ($this->session->get_userdata()['role'] == "trainer") {
                        $currentUser = $this->session->get_userdata()['user_id'];
                        $pagination["filters"][] = "created_by='$currentUser'";
                    }
                }

                if (count($pagination["filters"]) > 0) {
                    $wherePart = " where " . implode(" AND ", $pagination["filters"]);
                }

                $sql = "SELECT * FROM task_lists $wherePart ORDER BY $sort_by $sort_order LIMIT {$pagination['start']},{$pagination['end']}";
                $query = $this->db->query($sql);
            }
        }

        $result = $query->result_array();
        $data_array = $this->stripslashes_data($result, 'details');
        return $data_array;
    }

    function getTasksCount($pagination = null) {

        if ($pagination) {
            $wherePart = "";

            if ($this->session->get_userdata() && isset($this->session->get_userdata()['role'])) {
                if ($this->session->get_userdata()['role'] == "trainer") {
                    $currentUser = $this->session->get_userdata()['user_id'];
                    $pagination["filters"][] = "created_by='$currentUser'";
                }
            }

            if (count($pagination["filters"]) > 0) {
                $wherePart = " where " . implode(" AND ", $pagination["filters"]);
            }

            $sql = "SELECT count(*) as count FROM task_lists $wherePart";
            $query = $this->db->query($sql);
        }

        return $query->result_array()[0]["count"];
    }

    function getTaskActivities() {

        $sql = "SELECT distinct activity_id,activity_name,activity_type from task_lists";
        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function getTaskCreatedBy() {

        $sql = "select user_name, user_id from users where user_id in (select distinct created_by from task_lists)";
        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function getTasksByUser($id = "") {
        if (!empty($id)) {
            $query = $this->db->select('activity_name,activity_type,course_category,task_id')->from('task_lists')->where('user_id', $id)->where_in('task_status', array('in progress', 'assigned'))->get();
        } else {
            $query = $this->db->get('task_lists');
        }
        $result = $query->result_array();
        $data_array = $this->stripslashes_data($result, 'details');
        return $data_array;
    }

    /*
     * Insert task data
     */

    public function addTask($data = array()) {

        if (!array_key_exists('created', $data)) {
            $data['created'] = date("Y-m-d H:i:s");
        }
        if (!array_key_exists('modified', $data)) {
            $data['modified'] = date("Y-m-d H:i:s");
        }
        $insert = $this->db->insert('tasks', $data);
        if ($insert) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    /*
     * Modify task data
     */

    public function updateTask($data, $id) {
        if (!empty($data) && !empty($id)) {
            if (!array_key_exists('updated_date', $data)) {
                $data['updated_date'] = date("Y-m-d H:i:s");
            }
            $update = $this->db->update('tasks', $data, array('task_id' => $id));
            return $update ? true : false;
        } else {
            return false;
        }
    }

    /*
     * Modify task data
     */

    /*
      public function updateTaskHistory($data, $id) {
      if (!empty($data) && !empty($id)) {
      if (!array_key_exists('updated_date', $data)) {
      $data['updated_date'] = date("Y-m-d H:i:s");
      }
      $update = $this->db->update('task_updates', $data, array('task_id' => $id));
      return $update ? true : false;
      } else {
      return false;
      }
      }
     */

    /*
     * Delete user data
     */

    public function deleteTask($id) {
        $delete = $this->db->delete('tasks', array('task_id' => $id));
        return $delete ? true : false;
    }

    /*
     * Fetch task data
     */

    function taskExists($user_id, $task_id) {

        $this->db->select('task_id');
        $this->db->from('tasks');
        $this->db->where('task_id', $task_id);
        $this->db->where('user_id', $user_id);
        $query = $this->db->get();

        $result = $query->result_array();

        if (count($result) > 0) {
            return TRUE;
        } else {
            return false;
        }
    }

    function getTasksHistory($task_id, $data = "") {
        /* this is the sql query, I am trying to constuct using codeigniter db classes
         * select * from task_updates
         * LEFT JOIN tasks on tasks.task_id = task_updates.task_id
         * where task_updates.task_id='t1' AND tasks.user_id = '<users_id>'
         */

        if ($this->taskExists($data->users_id, $task_id)) {

            $this->db->select('task_updates.updated_date AS timestamp', 'update_type', 'content');
            $this->db->select('update_type AS type', 'content');
            $this->db->select('content');
            $this->db->from('task_updates');
            $this->db->join('tasks', 'tasks.task_id = task_updates.task_id');
            $this->db->where('task_updates.task_id', $task_id);
            $this->db->where('tasks.user_id', $data->users_id);
            $query = $this->db->get();

            $result = $query->result_array();
            $data_array = $this->stripslashes_data($result, 'content');

            return $data_array;
        } else {
            return array("error" => "task doesnt exist");
        }
    }

    /*
     * Insert task History data
     */

    public function taskHistoryUpdate($data = array()) {
        $sql = "INSERT INTO task_updates(`task_id`,`updated_date`,`update_type`,`content`,`update_id`) VALUES(?,?,?,?,?)";
        $insert = $this->db->query($sql, array($data['task_id'], $data['updated_date'], $data['update_type'], $data['content'], $data['update_id']));

        if ($insert) {
            return $insert;
        } else {
            return false;
        }
    }

    public function taskAssignInsert($data = array()) {

        $task_id = uniqid("task") . time();

        $data["task_id"] = $task_id;
        $data["task_status"] = "assigned";

        $sql = "INSERT INTO tasks(task_id, user_id,created_by, activity_id, start_date, end_date, parent_task_id, task_status)"
                . " VALUES(?,?,?,?,?,?,?,?)";

        $insert = $this->db->query($sql, array($data['task_id'], $data['user_id'], $data['current_user'], $data['activity_id'],
            $data['start_date'], $data['end_date'], $data['parent_task_id'], $data['task_status']));

        if ($insert) {
            return $insert;
        } else {
            return false;
        }
    }

    public function taskCount() {
        $insert = $this->db->count_all_results('task_updates');
        if ($insert) {
            return $insert;
        } else {
            return false;
        }
    }

    public function stripslashes_data($data, $decoding_field) {
//print_r($data);
        $new_data_array = array();
        if (is_array($data)) {
            foreach ($data as $data_array) {
                if (isset($data_array[$decoding_field])) {
                    $decoded_data = json_decode($data_array[$decoding_field]);
                    $data_array[$decoding_field] = $decoded_data;
                }
                $new_data_array[] = $data_array;
            }
        } else {
            $new_data_array = $data;
        }

        return $new_data_array;
    }

    /*
     * get tasks by task id
     */

    function getTasksByid($id = "") {
        if (!empty($id)) {
            $query = $this->db->select('task_id,user_id,')->from('tasks')->where('task_id', $id)->get();
        } else {
            $query = $this->db->get('tasks');
        }
        $result = $query->result_array();
        return $result;
    }

    /*
     * get tasks by task id
     */

    function getTasksDetailsByid($id = "") {
        if (!empty($id)) {
            $query = $this->db->select('task_id,task_status,user_name,user_id,activity_name,details')->from('task_lists')->where('task_id', $id)->get();
        } else {
            $query = $this->db->get('task_lists');
        }
        $result = $query->result_array();
        return $result;
    }

    function getTasks_History($task_id = "") {
        $sort_order = 'asc';
        $sort_by = 'updated_date';
        if (!empty($task_id)) {
            $this->db->select('update_id, task_id, update_type, content, updated_date');
            $this->db->from('task_updates');
            $this->db->where('task_id', $task_id);
            $this->db->order_by($sort_by, $sort_order);
            $query = $this->db->get();
        } else {
            $this->db->select('update_id, task_id, update_type, content, updated_date');
            $query = $this->db->get('task_updates');
            //$this->db->order_by($sort_by, $sort_order);
        }
        return $result = $query->result_array();
    }

    /*
     * Insert task data
     */

    public function addFile($data = array()) {
        $insert = $this->db->insert('training_files', $data);
        if ($insert) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    /*
     * Insert task data
     */

    public function getFile($file_id = NULL) {
        if (!empty($file_id)) {
            $query = $this->db->get_where('training_files', array('file_id' => $file_id));
            return $result = $query->result_array();
        } else {
            return null;
        }
    }

    function imageResize($width, $height, $target) {
        //takes the larger size of the width and height and applies the formula accordingly...this is so this script will work 	dynamically with any size image
        if ($width > $height) {
            $percentage = ($target / $width);
        } else {
            $percentage = ($target / $height);
        }

        //gets the new value and applies the percentage, then rounds the value
        $width = round($width * $percentage);
        $height = round($height * $percentage);

        //returns the new sizes in html image tag format...this is so you can plug this function inside an image tag and just get the

        return array("width" => $width, "height" => $height);
    }

}

?>
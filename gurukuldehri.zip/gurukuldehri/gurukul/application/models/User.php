<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class User extends CI_Model {

    public function __construct() {
        parent::__construct();

        //load database library
        $this->load->database();
    }

    /*
     * Fetch user data
     */

    function getRows($id = "") {
        if (!empty($id)) {
            $query = $this->db->get_where('users', array('id' => $id));
            return $query->row_array();
        } else {
            $query = $this->db->select('user_id,user_name')->from('users')->get();
            return $query->result_array();
        }
    }

    /*
     * Insert user data
     */

    public function insert($data = array()) {
        $insert = $this->db->insert('users', $data);
        if ($insert) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * Update user data
     */

    public function update($data, $id) {
        if (!empty($id)) {
            $update = $this->db->update('users', $data, array('user_id' => $id));
            return $update ? true : false;
        } else {
            return false;
        }
    }

    /*
     * Delete user data
     */

    public function delete($id) {
        $delete = $this->db->delete('users', array('id' => $id));
        return $delete ? true : false;
    }

    public function login($userdata, $calltype = '') {
        $q = $this->db->select('password,user_id,user_name')->from('users')->where('user_id', $userdata['user_id'])->get()->row();

        if ($q == "") {
            return 204;
        } else {
            $hashed_password = $q->password;
            $user_id = $q->user_id;
            if ($userdata['password'] == $hashed_password) {
                $last_login = date('Y-m-d H:i:s');

                //generating token				
                $salt = $salt = $this->config->item('salt_tocken_value');
                $password = $userdata['password']; // from json body - this is just exmaple
                $un = uniqid();
                $timestamp = time();
                $token = hash('sha256', $password . $user_id . $un . $timestamp . $salt);

                $expired_at = date("Y-m-d H:i:s", strtotime('+720 hours'));
                $this->db->trans_start();
                $this->db->where('user_id', $user_id)->update('users', array('last_login' => $last_login));

                $delete = $this->db->delete('users_authentication', array('users_id' => $user_id));

                $this->db->insert('users_authentication', array('users_id' => $user_id, 'token' => $token, 'expired_at' => $expired_at));
                if ($this->db->trans_status() === FALSE) {
                    $this->db->trans_rollback();
                    return 500;
                } else {
                    $this->db->trans_commit();
                    if ($calltype == 'web')
                        return array('user_id' => $user_id, 'token' => $token, 'token_expiration_time' => $expired_at, 'user_name' => $q->user_name);
                    else
                        return array('user_id' => $user_id, 'token' => $token, 'token_expiration_time' => $expired_at);
                }
            } else {
                //return array('status' => 204,'message' => 'Wrong password.');
                return 204;
            }
        }
    }

    /*
     * Function to if user is authorised/token
     */

    public function auth() {
        $token = $this->input->get_request_header('Authorization', TRUE);
        $q = $this->db->select('users_id,expired_at')->from('users_authentication')->where('token', $token)->get()->row();
        //echo $this->db->last_query();exit();
        if ($q == "") {
            return 205;
        } else {
            if ($q->expired_at < date('Y-m-d H:i:s')) {
                return 206;
            } else {
                $updated_at = date('Y-m-d H:i:s');
                $expired_at = date("Y-m-d H:i:s", strtotime('+720 hours'));
                $this->db->where('users_id', $q->users_id)->where('token', $token)->update('users_authentication', array('expired_at' => $expired_at, 'updated_at' => $updated_at));
                return $q;
            }
        }
    }

    function get_role_access($user_id = null) {
        if ($user_id) {
            $this->db->select('GROUP_CONCAT(user_roles_access.menu) as access');
            $this->db->from('user_roles');
            $this->db->join('user_roles_access', 'user_roles_access.role = user_roles.role');
            $this->db->where('user_roles.user_id', $user_id)->where('status','Y');
            $query = $this->db->get();
            $result = $query->result_array();

            if ($result) {
                $roleAccess = $result[0];

                $this->db->select('role');
                $this->db->from('user_roles');
                $this->db->where('user_id', $user_id);

                $query = $this->db->get();
                $result = $query->result_array();
                $roleAccess["role"] = $result[0]["role"];

                return $roleAccess;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    function get_user_details($pagination, $user_id = 0) {

        if ($user_id) {
            $this->db->select('users.user_id, user_name, last_login, email, password, user_roles.role');
            $this->db->from('users');
            $this->db->join('user_roles', 'user_roles.user_id = users.user_id');
            $this->db->where('users.user_id', $user_id);
            $query = $this->db->get();
            $result = $query->result_array();
        } else {
            $sql = "SELECT `users`.`user_id`, `user_name`, `last_login`, 
						user_roles.`role`, (select GROUP_CONCAT(menu) from user_roles_access where user_roles_access.role=user_roles.role) as access
					FROM `users` 
					LEFT JOIN `user_roles` ON `user_roles`.`user_id` = `users`.`user_id` 
					LIMIT {$pagination['start']},{$pagination['end']}";
            $query = $this->db->query($sql);
            $result = $query->result_array();
        }
        return $result;
    }

    function get_all_user() {
        $query = $this->db->from('users');
        return $this->db->count_all_results();
    }

    /*
     * Insert user role data
     */

    public function insertUserRole($data = array(), $action = 'add', $id = 0) {
        //echo $id;exit();
        if ($action == 'add') {
            $insert = $this->db->insert('user_roles', $data);
            return ($insert == true) ? true : false;
        } else {
            $update = $this->db->update('user_roles', $data, array('user_id' => $id));
            return ($update == true) ? true : false;
        }
    }

    public function create_users_from_csv($sql) {
        if ($sql) {
            $query = $this->db->query($sql);
            //$result = $query->result_array();
            if ($query)
                return true;
            else
                return false;
        } else
            return false;
    }
    
    /*
     * Function to create group
     */
    public function create_group($data){
    	//$this->db->from('groups');
    	//$this->db->where('group_id', $data['group_id']);
    	//$total_group= $this->db->count_all_results();
    	//if($total_group==0){
    		$insert = $this->db->insert('groups', $data);
    		return ($insert == true) ? $data["group_id"]: false;
    	/*}else{
    		$query = $this->db->get();
    		$result = $query->result_array();
    		return $result[0]["group_id"];
    	}*/
    }
    
    public function getGroups($id=null){
    	if (!empty($id)) {
    		$query = $this->db->get_where('groups', array('group_id' => $id));
    		return $query->row_array();
    	} else {
    		$query = $this->db->select('group_id,group_name,group_details,created_date')->from('groups')->get();
    		return $query->result_array();
    	}
    }
    
    public function getGroupsUser($id=null){
    	if (!empty($id)) {
    		$query = $this->db->get_where('group_users', array('group_id' => $id));
    		return $query->result_array();
    	} else {
    		$query = $this->db->select('group_id,user_id')->from('group_users')->get();
    		return $query->result_array();
    	}
    }
    
    
    public function getPackage(){
    	$package_list = array();
    	$package = array();
    	$package["name"] = "AR PHOTO Training";
    	$package["package"] = "AR_PHOTO_Training";
    	$package["activites"] = array();
    	$package["activites"][] = array("id" => 'ca1', "name" => "eCollection AR Photo Training", "type" => "education", "parent" => null);
    	$package["activites"][] = array("id" => 'ca2', "name" => "eCollection AR Photo Training", "type" => "validation", "parent" => "ca1");
    	$package["activites"][] = array("id" => 'ca3', "name" => "eCollection AR Photo Training", "type" => "validation", "parent" => "ca2");
    	
    	return $package;
    }
}
?>
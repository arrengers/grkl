<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Course_activities_model extends CI_Model {
	
	public function __construct() {
		parent::__construct();
		
		//load database library
		$this->load->database();
	}
	
	
}
?>
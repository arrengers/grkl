<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Course_model extends CI_Model {
	
	public function __construct() {
		parent::__construct();
		//load database library
		$this->load->database();
	}
	
	/*
	 * Fetch user data
	 */
	function getCourse($id = ""){

		if(!empty($id)){
			$query = $this->db->get_where('courses', array('course_id' => $id));
			//echo $this->db->last_query();
			return $query->row_array();
		}else{
			$query = $this->db->get('courses');
			return $query->result_array();
		}
	}
	
	/*
	 * Function to add cources
	 */
	function addCourse($data= ""){
		$insert = $this->db->insert('courses', $data);
		return $this->db->affected_rows();
	}
	
	/*
	 * Function to update cources
	 */
	function updateCourse($data= ""){
		$this->db->set('course_name', $data['course_name']);
		$this->db->where('course_id',$data['course_id']);
		$update = $this->db->update('courses'); // gives UPDATE coursesSET course_name= $course_name WHERE course_id= $course_id
		return $this->db->affected_rows();
	}
		
	/*
	 * function to count course
	 */
	
	function countRows($countRows = 'courses'){	
	//function countCourse(){
		return $course_all = $this->db->count_all($countRows);
	}

	/*
	 * Fetch course Activity data
	 */
	function getCourseActivities($data= ""){
		if(!empty($data)){
			$query = $this->db->get_where('activity_details', $data);
			return $query->result_array();
		}else{
			$query = $this->db->get('activity_details');
			return $query->result_array();
		}
	}
	/*
	 * Insert task data
	 */
	public function addCourseActivities($data = array()) {
		$insert = $this->db->insert('course_activities', $data);
		return $this->db->affected_rows();
	}
	
	
	/*
	 * Modify task data
	 */
	public function updateCourseActivities($data, $id) {
		$update = $this->db->update('course_activities', $data, array('activity_id'=>$id));
		return $update?true:false;
	}
	
	/*
	 * Delete user data
	 */
	public function deleteCourseActivities($id){
		$delete = $this->db->delete('course_activities',array('activity_id'=>$id));
		return $delete?true:false;
	}
	
	/*
	 * Fetch user data
	 */
	function getCategories($category_id= ""){
		if(!empty($category_id)){
			$query = $this->db->get_where('categories', array('category_id' => $category_id));
			return $query->result_array();
		}else{
			$query = $this->db->get('categories');
			return $query->result_array();
		}
	}
	
	/*
	 * Function to add category
	 */
	function addCategory($data= ""){
		$insert = $this->db->insert('categories', $data);
		return $this->db->affected_rows();
	}
	
	/*
	 * Function to update category
	 */
	function updateCategory($data= ""){
		$this->db->set('category_name', $data['category_name']);
		$this->db->where('category_id',$data['category_id']);
		$update = $this->db->update('categories'); // gives UPDATE categories SET category_name= $category_name WHERE category_id= $category_id
		return $this->db->affected_rows();
	}
	
}
?>
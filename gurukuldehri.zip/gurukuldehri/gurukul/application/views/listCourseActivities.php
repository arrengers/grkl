<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend style="height: 50px;">
                                <span>Activity List</span>
                                <a class='btn btn-primary' style='float:right' href="<?php echo base_url() . 'index.php/course/updateCourseActivities?action=add'; ?>">Add New Activity</a>
                            </legend>


                            <table id="example" class="table table-striped">
                                <thead>
                                    <tr class='table-striped'>
                                        <th width="20%">Activity</th>
                                        <th width="30%">Info</th>			                
                                        <th width="50%">Properties</th>
                                    </tr>
                                    <?php
                                    if (@$activityList) {

                                        function printProperties($array, $offset) {
                                            foreach ($array as $key => $value) {

                                                $keyName = str_replace("_", " ", $key);
                                                $keyName = ucwords($keyName);

                                                if (is_array($value)) {
                                                    echo "$offset<strong>$keyName:</strong><br>";
                                                    printProperties($value, $offset . "&nbsp;&nbsp;&nbsp;&nbsp;");
                                                } else {
                                                    echo "$offset<strong>$keyName:</strong> $value<br>";
                                                }
                                            }
                                        }

                                        foreach ($activityList as $activity) {
                                            //print_r($activity);
                                            ?>
                                            <tr>
                                                <td><a href='<?php echo base_url() . "index.php/course/updateCourseActivities?action=edit&course_id=" . @$course_id . "&activity_id=" . $activity['activity_id']; ?>'><?php echo $activity['activity_name']; ?></a></td>
                                                <td>
                                                    <?php echo "<b>Type: </b>" . $activity['type']; ?><br>	
                                                    <?php echo "<b>Category: </b>" . $activity['category_name']; ?></br>
                                                    <?php echo "<b>Course: </b>" . $activity['course_name']; ?>
                                                </td>	
                                                <td>
                                                    <div style="font-size: 11px;">
                                                        <?php
                                                        $properties = json_decode($activity['details'], TRUE);
                                                        printProperties($properties, "");

                                                        /*
                                                          if (is_string($activity['details'])) {
                                                          echo stripcslashes($activity['details']);
                                                          } else {
                                                          echo $activity['details'];
                                                          }
                                                         */
                                                        ?>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </thead>
                                </tbody>
                            </table>


                        </div>
                    </div>

                </div>

            </div>
        </div>



    </body>
</html>

<?php $this->load->view("header"); ?>
<title>Nielsen LMS- Course List</title>  
<!-- All these files are taken from cxar -->
<!-- Bootstrap Core CSS -->
<link href="<?php echo base_url().'assets/css/bootstrap.min.css'; ?>" rel="stylesheet">
<!-- MetisMenu CSS -->
<link href="<?php echo base_url().'assets/css/metisMenu.min.css'; ?>" rel="stylesheet">
<!-- Timeline CSS -->
<link href="<?php echo base_url().'assets/css/timeline.css'; ?>" rel="stylesheet">
<!-- Custom CSS -->
<link href="<?php echo base_url().'assets/css/startmin.css'; ?>" rel="stylesheet">
<!-- Morris Charts CSS -->
<link href="<?php echo base_url().'assets/css/morris.css'; ?>" rel="stylesheet">
<!-- Custom Fonts -->
<link href="<?php echo base_url().'assets/css/font-awesome.min.css'; ?>" rel="stylesheet" type="text/css"></head>

    <!-- jQuery -->
    <script src="<?php echo base_url().'assets/js/myFunctions.js';?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/simplePagination.css'; ?>">
    <script type="text/javascript" src="<?php echo base_url().'assets/js/jquery.simplePagination.js'; ?>"></script>
    <script>
        // startPagination() function's parameter object
        var paginationObj = {
        	targetDivId    : "target-content",
        	pageURL        : "<?php echo base_url().'index.php/course/getCourseAjax'?>",               // use for delete ajax page url
        	paginationUrl  : "<?php echo base_url().'index.php/course/getCourseAjax?page='?>",         // after delete pagination reset
        	perPageRecord  : "<?php echo '10'; //PER_PAGE_RECORD;?>",  // after delete pagination reset
        	checkboxArrayName : "userid",
        	searchBoxId    : "search",
        	extraParameter : 0                       // put 0 when parameter not required
};

$(document).ready(function(){
	startPagination(paginationObj);
});
</script>
</head>
<body>
	
<div id="wrapper">
	
	<!-- Top header and menu -->
    <?php $this->load->view("header_menu"); ?>

    <!-- Page Content -->
    <div id="page-wrapper">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">User list<a href="adduser.php" class="btn btn-primary pull-right" role="button">Add User</a></h1>
                    <div class="row">
                        <div class="col-md-8">
                          <button type="button" class="btn btn-danger pull-left" onclick="deleteCheckboxRecord(paginationObj)">Delete</button>
                        </div>
                        <div class="col-md-4">
                          <input type="text" id="search" placeholder="Search (email or firstname)" onkeyup="searchDataAjax(this,paginationObj)"  class="form-control pull-right">
                        </div>
                    </div>
                    <div class="errorStatus"></div>
                    <div class="table-responsive">
                        <table class="table">
                          <thead>
                            <tr>
								<th><input type="checkbox" onclick="chkAllcheckbox(this)"></th>
	                            <!-- th>SNo.</th-->
					         	<th>Course Id</th>
			                	<th>Course Name</th>
			                	<!-- th>Add/Edit Activities</th-->
                            </tr>
                          </thead>
                          <tbody id="target-content">
                          </tbody>
                        </table>
                    </div>
                    <div class="text-center" id="paginationLink"></div>
                </div>
            </div>
        </div>

            <!-- ... Your content goes here ... -->
  </div>

</div>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url().'assets/js/libs/bootstrap.min.js';?>"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url().'assets/js/libs/metisMenu.min.js';?>"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url().'assets/js/libs/startmin.js';?>"></script>

</body>
</html>

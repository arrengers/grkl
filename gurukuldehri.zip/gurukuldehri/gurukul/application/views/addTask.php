<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Course Details</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">
        
        <link rel="stylesheet" href="<?php echo APPPATH; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPPATH; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <script src="<?php echo APPPATH; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPPATH; ?>assets/js/libs/bootstrap.min.js"></script>
    </head>
    <body>
   
 <div class="row">
    <div class="col-md-4 col-md-offset-4">
      <form class="form-horizontal" role="form">
        <fieldset>
          <!-- Form Name -->
          <legend>Task Details</legend>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Activity Name</label>
            <div class="col-sm-10">
              <input type="text" placeholder="Activity Name" class="form-control">
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Course Category</label>
            <div class="col-sm-10">
	            <select class='form-control property_type' name='property_type' onchange='updatePropertyType(this)'>
					<option value='timer' selected='selected'>eCollection</option>
					<option value='url'>LHHT</option>
				</select>
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Activity Type</label>
            <div class="col-sm-10">
              <input type="text" placeholder="Activity Type" class="form-control">
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Start Date</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control">
            </div>

            <label class="col-sm-2 control-label" for="textinput">End Date</label>
            <div class="col-sm-4">
              <input type="text" placeholder="" class="form-control">
            </div>
          </div>



          <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Json Details</label>
            <div class="col-sm-10">
              <input type="text" placeholder="Json Details" class="form-control">
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Chat Mesasges</label>
            <div class="col-sm-10">
              <input type="text" placeholder="Chat Mesasges" class="form-control">
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Help</label>
            <div class="col-sm-10">
              <a herf="#">Help Link</a>
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Status History</label>
            <div class="col-sm-10">
              History
            </div>
          </div>

          <!-- Text input-->
          <div class="form-group">
            <label class="col-sm-2 control-label" for="textinput">Current Status</label>
            <div class="col-sm-10">
              Current Status
            </div>
          </div>


          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <div class="pull-right">
                <button type="submit" class="btn btn-default">Execute</button>
                <!--button type="submit" class="btn btn-primary">Save</button-->
              </div>
            </div>
          </div>

        </fieldset>
      </form>
    </div><!-- /.col-lg-12 -->
</div><!-- /.row -->


   
<div class="clear"></div>
<?php $this->load->view("footer"); ?>  
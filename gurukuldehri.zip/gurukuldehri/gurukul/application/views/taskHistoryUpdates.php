<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>/assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>/assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>/assets/css/style.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">
        <link rel="stylesheet" href="https://raw.githubusercontent.com/mistic100/Bootstrap-Confirmation/master/bootstrap-confirmation.min.js">




        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
                <!-- script src="<?php echo APPHOST; ?>assets/js/libs/highcharts.js"></script>
                <script src="<?php echo APPHOST; ?>assets/js/libs/series-label.js"></script--> 
        <script src="https://code.highcharts.com/highcharts.js"></script>
        <script src="https://code.highcharts.com/modules/series-label.js"></script>
        <style>
            #container_linechart {
                min-width: 310px;
                /*max-width: 600px;*/
                height: 400px;
                margin: 0 auto
            }
            .progress-bar{
                text-align: left!important;
                padding-left:10px;
            }

            .width20per{
                width:20%!important;
                padding-left:10px;
                padding-top:10px;			
                padding-bottom:10px;			
            }

            .width30per{
                width:30%!important;
                padding-left:10px;			
                padding-top:10px;			
                padding-bottom:10px;			
            }


        </style>  
    </head>
    <body>

        <div id="wrapper">
            <?php $active = 'active'; ?>
            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <legend style="height: 50px;">
                                <span>
                                    <?php echo @$history_status[0]['activity_name']; ?>
                                </span>
                                <?php
                                $status = $history_status[0]['task_status'];

                                if (in_array($status, array('in review'))) {
                                    echo "<button type='button' class='btn btn-primary' style='float:right; margin: 10px;' data-toggle='modal' data-target='#reassignModal'>Re-Assign Task</button>";
                                }

                                if (in_array($status, array('in review'))) {
                                    echo "<button type='button' class='btn btn-success' style='float:right; margin: 10px;' data-toggle='modal' data-target='#approveTaskModal'>Approve Task</button>";
                                }

                                if (in_array($status, array('assigned', 'in progress', 'in review'))) {
                                    echo "<button type='button' class='btn btn-warning' style='float:right; margin: 10px;' data-toggle='modal' data-target='#closeTaskModal'>Close Task</button>";
                                }
                                ?>

                                <button type='button' class='btn btn-default' style='float:right; margin: 10px;' data-toggle='modal' data-target='#messageModal'>Message</button>
                                <button onclick="window.history.back()" class='btn btn-default align-Right' style='float:right; margin: 10px;'  role='button'>Back</button>
                            </legend>


                            <div class="panel panel-primary">
                                <div class="panel-body">

                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Current Status</th>
                                                <th>Assignee</th>
                                                <th>Assigned Count</th>

                                                <?php
                                                if ($photo_activity) {
                                                    echo "<th>Photos Taken</th>";
                                                    echo "<th>Avg. Time Taken</th>";
                                                }
                                                ?>
                                            </tr>
                                        </thead>

                                        <?php
                                        $assignedCount = 1;
                                        $photosTaken = 0;
                                        $timeTaken = 0;

                                        foreach ($history as $historydata) {
                                            $updates = json_decode(@$historydata['content'], true);

                                            if ($historydata['update_type'] == 'status' && $updates["current_status"] == "assigned") {
                                                $assignedCount++;
                                            } else if ($historydata['update_type'] == 'file_attach') {
                                                $photosTaken++;

                                                if (isset($updates["time_taken"])) {
                                                    $timeTaken += $updates["time_taken"];
                                                }
                                            }
                                        }
                                        ?>

                                        <tbody>
                                            <tr>
                                                <td><?php echo ucwords(@$history_status[0]['task_status']); ?></td>
                                                <td><?php echo @$history_status[0]['user_name']; ?></td>
                                                <td><?php echo $assignedCount; ?></td>

                                                <?php
                                                if ($photo_activity) {

                                                    $avgTimeTaken = 0;

                                                    if ($timeTaken > 0) {
                                                        $avgTimeTaken = round($timeTaken / $photosTaken, 2);
                                                    }

                                                    echo "<td>$photosTaken</td>";
                                                    echo "<td>{$avgTimeTaken}s</td>";
                                                }
                                                ?>

                                            </tr>
                                        </tbody>
                                    </table>


                                </div>
                            </div>


                            <?php
                            if (@$history) {
                                foreach ($history as $historydata) {
                                    ?>

                                    <div class="panel panel-default">
                                        <div class="panel-heading" style="height: 35px;">
                                            <span style="float: left;  font-weight: bold;"><?php echo @str_replace('_', ' ', ucwords($historydata['update_type'])); ?></span>
                                            <span style="float: right;"><?php echo @$historydata['updated_date']; ?></span>
                                        </div>
                                        <div class="panel-body">

                                            <div>
                                                <?php
                                                $content = null;

                                                $updates = json_decode(@$historydata['content'], true);
                                                $file_id = $file_location = null;

                                                if ($historydata['update_type'] == 'status') {
                                                    echo "<i>Status changed from '" . ucwords($updates['previous_status']) . "' to <strong>'" . ucwords($updates['current_status']) . "'</strong></i><br>";
                                                    echo "<strong  style='color:#777;'>Assignee:</strong> {$updates['assignee']}";
                                                } else if ($historydata['update_type'] == 'message') {
                                                    echo "<i><strong style='color:#777;'>[" . ucwords($updates['sender']) . "]</strong> </i> >> {$updates['message']}";
                                                } else if ($historydata['update_type'] == 'data_update') {

                                                    $rotate_bar_value = array();
                                                    $up_down_bar_value = array();
                                                    $left_right_bar_value = array();

                                                    $startRange = $this->config->item('red_green_dsply_val_fr_green_range_1');
                                                    $endRange = $this->config->item('red_green_dsply_val_fr_green_range_2');
                                                    $progressBar = '';
                                                    //$content .= "<div id='container_linechart'></div><br>";
                                                    foreach ($updates as $vdata) {
                                                        foreach ($vdata as $vdata2) {
                                                            $content .= "<div class='col-lg-3'>";
                                                            foreach ($vdata2 as $k => $v) {
                                                                if (in_array($k, array('rotate_bar', 'up_down_bar', 'left_right_bar'))) {

                                                                    if ($k == 'rotate_bar') {
                                                                        $rotate_bar_value[] = (float) $v;
                                                                    } else if ($k == 'up_down_bar') {
                                                                        $up_down_bar_value[] = (float) $v;
                                                                    } else if ($k == 'left_right_bar') {
                                                                        $left_right_bar_value[] = (float) $v;
                                                                    }

                                                                    $class = '';
                                                                    $d = $v * 100;
                                                                    if ($v >= $startRange && $v < $endRange) {
                                                                        $class = 'progress-bar-success';
                                                                    } else {
                                                                        $class = 'progress-bar-danger';
                                                                    }

                                                                    $barTitle = str_replace('_bar', '', $k);
                                                                    $barTitle = str_replace('_', ' ', $barTitle);
                                                                    $barTitle = ucwords($barTitle);

                                                                    $content .= "<div class='progress' style='width:200px; margin-bottom:5px;'>";
                                                                    $content .= "<div class='progress-bar $class' role='progressbar' aria-valuenow='40' aria-valuemin='0' aria-valuemax='100' style='width:$d%; height:20px;'>";
                                                                    $content .= "<span style='font-size:11px;'>" . round($d) . '%</span>';
                                                                    $content .= "</div>";
                                                                    $content .= "<span style='font-size:10px; float:right; margin-right:5px; margin-top:2px;'>" . $barTitle . ' </span>';
                                                                    $content .= "</div>";
                                                                }
                                                                if ($k == 'hint') {
                                                                    $hint = "---";

                                                                    if (!empty(trim($v))) {
                                                                        $hint = $v;
                                                                    }

                                                                    $content .= "<div style='margin-bottom:5px;'><i>$hint</i></div>";
                                                                }
                                                            }
                                                            $content .= '</div>';
                                                        }
                                                    }
                                                    ?>
                                                    <div class="">
                                                        <div class="row">
                                                            <?php
                                                            echo $content . "&nbsp;";
                                                            $content = null;
                                                            ?>
                                                        </div>
                                                    </div>

                                                    <?php
                                                } else if ($historydata['update_type'] == 'file_attach') {
                                                    $file_id = $updates["file_id"];
                                                    $file_location = $updates["file_location"];
                                                    $thumbnail_location = "/training_files/thumbnails/$file_location";
                                                    
                                                    if (!file_exists($thumbnail_location)) {
                                                        echo "no thumbnail";
                                                    }
                                                    
                                                    if ($file_location != null) {
                                                        echo "<a href='/training_files/$file_location' target='_blank'><img src='/training_files/$file_location' height='300'></a>";
                                                    }

                                                    if (isset($updates["time_taken"])) {
                                                        echo "<br><br><i>Time Taken: <b>{$updates["time_taken"]}s</b></i>";
                                                    }

                                                    $content = null;
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>



                                    <?php
                                }
                            }
                            ?>

                        </div>
                    </div>


                    <!--  Re Assign Modal -->
                    <div class="modal fade" id="reassignModal" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Re-Assign Task</h4>
                                </div>
                                <div class="modal-body">
                                    <form>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">End Date</label>
                                            <input class="form-control" id="end_date" name="end_date" placeholder="YYYY-MM-DD" type="text" />
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <a href='<?php echo base_url() . "index.php/course/reassignTask?task_id=" . @$task_id . "&status=assign"; ?>'>
                                        <button type="button" class="btn btn-primary" data-dismiss="modal" id='reassignTask'>Re-Assign</button>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div> <!-- -->


                    <!--  Message Modal -->
                    <div class="modal fade" id="messageModal" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Message</h4>
                                </div>
                                <div class="modal-body">
                                    <textarea style="width: 550px; height: 150px;" id='messageField'></textarea>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary" data-dismiss="modal" id='sendMessage'>Send</button>
                                </div>
                            </div>
                        </div>
                    </div> <!-- -->

                    <!-- Close task Model -->
                    <div class="modal fade" id="closeTaskModal" role="dialog">
                        <div class="modal-dialog">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Clsoe Task</h4>
                                </div>
                                <div class="modal-body">
                                    Are you sure, you want to close task?
                                    <!-- textarea style="width: 550px; height: 150px;" id='messageField'></textarea-->
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary" data-dismiss="modal" id='closeTask'>Ok</button>
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div> 
                    <!-- Close task model ends here -->

                    <!-- Approve task Model -->
                    <div class="modal fade" id="approveTaskModal" role="dialog">
                        <div class="modal-dialog">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Approve Task</h4>
                                </div>
                                <div class="modal-body">
                                    Are you sure, you want to approve task?
                                    <!-- textarea style="width: 550px; height: 150px;" id='messageField'></textarea-->
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary" data-dismiss="modal" id='approveTask'>Ok</button>
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div> 
                    <!-- Approve task model ends here -->
                </div>
            </div>
        </div>
        <!-- Footer -->
        <?php
        $user_name = $this->session->userdata('user_name');
        $user_name = ($user_name != '') ? $user_name : $this->session->userdata('user_id');
        $this->load->view("footer");
        ?>          
    </body>
    <script>
        $(document).ready(function () {
            $('#sendMessage').click(function () {
                var vmessage = $('#messageField').val();
                var vtask_id = "<?php echo $task_id; ?>";
                $.post("<?php echo base_url() . 'index.php/course/addMessage?task_id=' . @$task_id ?>", //Required URL of the page on server
                        {// Data Sending With Request To Server
                            message: vmessage,
                            task_id: vtask_id,
                            user_name: "<?php echo $user_name; ?>"

                        },
                        function (response, status) { // Required Callback Function
                            alert(response);
                        });
                location.reload();
            });

            $('#reassignTask').click(function () {
                var vend_date = $('#end_date').val();
                var vtask_id = "<?php echo $task_id; ?>";

                $.post("<?php echo base_url() . 'index.php/course/reassignTask'; ?>",
                        {
                            end_date: vend_date,
                            task_id: vtask_id
                        },
                        function (response, status) { // Required Callback Function
                            //alert("*----Received Data----*\n\nResponse : " + response+"\n\nStatus : " + status);//"response" receives - whatever written in echo of above PHP script.
                            alert(response);
                        });
                location.reload();
            });

            $('#closeTask').click(function () {
                var vtask_id = "<?php echo $task_id; ?>";
                $.post("<?php echo base_url() . 'index.php/course/cancelTask?task_id=' . @$task_id . '&status=close' ?>", //Required URL of the page on server
                        function (response, status) { // Required Callback Function
                            if (response == 'success') {
                                url = "<?php echo base_url() . 'index.php/task/index?success=success' ?>";
                            } else {
                                url = "<?php echo base_url() . 'index.php/task/index?error=error' ?>";
                            }
                            $(location).attr("href", url);
                        });
            });

            $('#approveTask').click(function () {
                var vtask_id = "<?php echo $task_id; ?>";
                $.post("<?php echo base_url() . 'index.php/course/approveTask?task_id=' . @$task_id . '&status=approve' ?>", //Required URL of the page on server
                        function (response, status) { // Required Callback Function
                            if (response == 'success') {
                                url = "<?php echo base_url() . 'index.php/task/index?success=success' ?>";
                            } else {
                                url = "<?php echo base_url() . 'index.php/task/index?error=error' ?>";
                            }
                            $(location).attr("href", url);
                        });
            });

        });
    </script>
</html>

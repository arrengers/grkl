<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">
        
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend style="height: 50px;">
                                <span>Search Student</span>
                            </legend>


                            <form class="form" role="form" method="post" action='<?php echo base_url() . "index.php/fee/index"; ?>'>
                                <!-- div class="form-group">
                                    <label class="control-label" for="textinput">Choose Course</label>
                                    <?php echo $class_dropdown; ?>
                                </div-->

                                <div class="form-group">
                                    <label class="control-label" for="textinput">Student Unique ID</label>
                                    <input type="text" style="width: 40%;" placeholder="student Id" name="student_id" value="<?php echo set_value('student_id', @$fee['student_id']); ?>" class="form-control">
                                </div>

                                <!-- div class="form-group">
                                    <label class="control-label" for="textinput">Student Course</label>
                                    <input type="text" style="width: 40%;" placeholder="student Class" name="student_class" value="<?php echo set_value('student_class', @$fee['class']); ?>" class="form-control">
                                </div-->

                                <div class="form-group">
                                    <label class="control-label" for="textinput">Student Name</label>
                                    <input type="text" style="width: 40%;" placeholder="student Name" name="student_name" value="<?php echo set_value('student_name', @$fee['name']); ?>" class="form-control">
                                </div>

                                <!-- Text input-->
                                <div class="form-group">
                                    <button class='btn btn-primary'>Search Student</button>
                                </div>

                            </form>

                            <?php
                            if (@$studentDetails) {
                            ?>							
                            <table id="example" class="table table-striped" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Student Details</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                            <th>
                                            	<a href='<?php echo base_url() . "index.php/fee/collectFee?student_code=" . @$studentDetails['student_code']; ?>'>
                                            		<button type="button" class="btn btn-success">Pay Fee</button>
                                            	</a>
                                            </th>
                                        </tr>
                                     </thead>
                                    <tr>
                                    	<td>Student Name</td>
                                        <td>
                                        	<b><?php echo @$studentDetails['name']."(".$studentDetails['student_code'].")"; ?></b>
                                        </td>
                                    	<td>Roll No.</td>
                                        <td>
                                        	<b><?php echo @$studentDetails['rollno']; ?></b>
                                        </td>
                                    </tr>
                                    <tr>
                                    	<td>DOB</td>
                                        <td>
                                        	<b><?php echo @$studentDetails['dob']; ?></b>
                                        </td>
                                    	<td>Gender</td>
                                        <td>
                                        	<b><?php echo @$studentDetails['gender']; ?></b>
                                        </td>
                                    </tr>
                                    <tr>
                                    	<td>class/ section</td>
                                        <td><b>
                                        	<?php echo @$studentDetails['class']."/".$studentDetails['section']; ?>
                                        	</b>
                                        </td>
                                    	<td>academicyear</td>
                                        <td><b>
                                        	<?php echo @$studentDetails['academicyear']; ?>
                                        	</b>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                           <?php
                            }else {
                                echo "<div>No record found!</div>";
                            }
                           ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view("footer"); ?>          
    </body>
</html>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">

        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend style="height: 50px;">
                                <span>Add/Edit User</span>
                                <a href="<?php echo base_url() . "index.php/signin/get_users"; ?>" class="btn btn-default align-Right" style='float:right; margin: 10px;'  role="button">Back</a>

                            </legend>
							<?php if(@$success==1){?>
								<div class="alert alert-success alert-dismissable">
							    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    								<?php echo 'Data updated successfuly!'; ?>
							  </div>
							<?php }
							if(@$success==2){?>
							<div class="alert alert-danger alert-dismissable fade in">
							    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    								<?php echo 'There is an error updating your data, try later!'; ?>
							  </div>
							<?php }?>  
							
							<?php if(validation_errors()==true){?>
							<div class="alert alert-danger alert-dismissable fade in">
							    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    								<?php echo validation_errors(); ?>
							  </div>
							<?php }?>  

                            <form class="form-horizontal" role="form" method='post' action='<?php echo base_url() . "index.php/signin/add_user?user_id=" . @$user_id; ?>'>
                                <fieldset>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">First Name</label>
                                        <div class="col-sm-6">
                                            <input type="text" name='first_name' id='first_name' placeholder="First Name" value='<?php echo set_value('first_name', @$role_access[0]['first_name']); ?>'class="form-control">
                                        </div>
                                    </div>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Last Name</label>
                                        <div class="col-sm-6">
                                            <input type="text" name='last_name' id='last_name' placeholder="Last Name" value='<?php echo set_value('last_name', @$role_access[0]['last_name']); ?>'class="form-control">
                                        </div>
                                    </div>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">E-mail</label>
                                        <div class="col-sm-6">
                                            <input type="email" name='email' id='email' placeholder="Email" value='<?php echo set_value('email', @$role_access[0]['email']); ?>'class="form-control">
                                        </div>
                                    </div>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Password</label>
                                        <div class="col-sm-6">
                                            <input type="password" name='password' id='password' placeholder="Password" value='<?php echo set_value('password', @$role_access[0]['password']); ?>'class="form-control">
                                        </div>
                                    </div>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Role</label>
                                        <div class="col-sm-6">
                                            <?php echo @$role_dropdown; ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-sm-offset-2 col-sm-6">
                                            <div class="pull-right">
                                            	<input type='hidden' name='user_id' id='user_id' value='<?php echo @$role_access[0]['user_id']; ?>'>
                                            	<input type='hidden' name='action' id='action' value='<?php echo @$action; ?>'>
                                                <button type="submit" name='button' value= 'active' class="btn btn-primary">Save</button>
                                            </div>
                                        </div>
                                    </div>

                                </fieldset>
                            </form>


                        </div>
                    </div>

                </div>

            </div>
        </div>



    </body>
</html>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task List</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/style.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">
        
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <style>
            .sr-only{
                position: relative !important;
            }

            .centered {
                text-align: center;
            }

        </style>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend>Users List</legend>
                            <table id="example5" class="table table-striped" width="800px">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>User ID</th>
                                        <th>User Name</th>
                                        <th>Role</th>
                                        <th>Role Access</th>
                                        <th>Last Login</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //'users.user_id, user_name, last_login, user_roles.role, GROUP_CONCAT(user_roles_access.menu) as access'
                                    if (@$role_access) {
                                        $i = 0;
                                        foreach ($role_access as $roleaccess) {
                                            $i++;
                                            $last_login= "";
                                            $user_name= ucwords($roleaccess['user_name']);

                                            try {
                                            	$last_login= new DateTime($roleaccess['last_login']);
                                            	$last_login= $last_login->format('m/d/Y');
                                            } catch (Exception $e) {
                                                
                                            }

                                            ?>
                                            <tr>
                                                <th scope="row"><?php echo $i; ?></th>
                                                <td><?php echo $roleaccess['user_id']; ?></td>
                                                <td><a href='<?php echo base_url() . "index.php/signin/add_user?user_id=" . @$roleaccess['user_id']."&action=edit"; ?>'><?php echo @$user_name; ?></a></td>
                                                <td><?php echo ucfirst($roleaccess['role']); ?></td>
                                                <td><?php echo $roleaccess['access']; ?></td>
                                                <td><?php echo $last_login; ?></td>
                                            </tr>
                                            <?php
                                        }
                                    } else {
                                        ?>
                                        <tr>
                                            <td colspan='10'>No task found for this user!</td>
                                        </tr>
                                    <?php }
                                    ?>
                                </tbody>
                            </table>

                            <div class='centered'>
                                <ul class='li_style'  >
                                    <?php if ($curpage != $startpage) { ?>
                                        <li class="page-item li_style">
                                            <a class="page-link" href="?page=<?php echo $startpage ?>" tabindex="-1" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                                <span class="sr-only">First</span>
                                            </a>
                                            &nbsp;
                                        </li>
                                    <?php } ?>

                                    <?php if ($curpage >= 2) { ?>
                                        <li class="page-item li_style"><a class="page-link" href="?page=<?php echo $previouspage ?>"><?php echo $previouspage ?></a></li>
                                    <?php } ?>

                                    <li class="page-item active li_style"><a class="page-link" href="?page=<?php echo $curpage ?>"><b><?php echo $curpage ?></b></a></li>

                                    <?php if ($curpage != $endpage) { ?>
                                        <li class="page-item li_style"><a class="page-link" href="?page=<?php echo $nextpage ?>"><?php echo $nextpage ?></a></li>
                                    <?php } ?>

                                    <?php if ($curpage != $endpage) { ?>
                                        <li class="page-item li_style">
                                            <a class="page-link" href="?page=<?php echo $endpage ?>" aria-label="Next">
                                                &nbsp;
                                                <span class="sr-only">Last</span>
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>
                                    <?php } ?>

                                </ul>
                            </div>							
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <!-- Footer -->
        <?php $this->load->view("footer"); ?>          
    </body>
</html>

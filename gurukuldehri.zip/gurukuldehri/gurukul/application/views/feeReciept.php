<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Collect Fee</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">
        
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">
                            <legend style="height: 50px;">
                                <span>Pay Student Fee</span>
                                <a href="<?php echo base_url() . "index.php/fee"; ?>" class="btn btn-default align-Right" style='float:right;'  role="button">Back</a>
                            </legend>

                            <form class="form" role="form" method="post" action='<?php echo base_url() . "index.php/fee/collectFee"; ?>'>
                            <?php
                            if (@$studentDetails) {
                            ?>							
                            <table id="example" class="table table-striped" style='margin-top: -22px;' cellspacing="0">
                                    <tr>
                                    	<td style='width:25%;'>Student Name</td>
                                        <td style='width:25%;'>
                                        	<b><?php echo @$studentDetails['name']."(".$studentDetails['student_code'].")"; ?></b>
                                        </td>
                                    	<td style='width:25%;'>Roll No./Section</td>
                                        <td style='width:25%;'>
                                        	<b><?php echo @$studentDetails['rollno'].'/'.@$studentDetails['section']; ?></b>
                                        </td>
                                    </tr>
                                    <tr>
                                    	<td>DOB</td>
                                        <td>
                                        	<b><?php echo @$studentDetails['dob']; ?></b>
                                        </td>
                                    	<td>Gender</td>
                                        <td>
                                        	<b><?php echo @$studentDetails['gender']; ?></b>
                                        </td>
                                    </tr>
                                    <tr>
                                    	<td>Class/ Section</td>
                                        <td><b>
                                        	<?php echo @$studentDetails['class']."/".$studentDetails['section']; ?>
                                        	</b>
                                        </td>
                                    	<td>Academic year</td>
                                        <td><b>
                                        	<?php echo @$studentDetails['academicyear']; ?>
                                        	</b>
                                        </td>
                                    </tr>
                               </table>
							<br>
							<div align="center"><b><u>Fee due details</u></b></div>
							<hr>
							
							
							<?php if($payment_details) { 
							?>
                               <table id="example" class="table table-striped" cellspacing="0">
									<?php 
									$total = 0;
									foreach ($payment_details as $tF){
									    $total = $total + $tF['amount_paid'];
									?>
									    <tr>
                                            	<td colspan='3'><b><?php echo @$tF['amount_paid_for']; ?> </b></td>
                                            	<td colspan='1'> Rs. <b><?php echo @$tF['amount_paid']; ?></b></td>
                                           	</tr>
									<?php } ?>
                                            <tr>
                                            	<td colspan='3'><b>Total Amount </b></td>
                                            	<td colspan='1'> Rs. <b><?php echo $total.'.00'; ?></b></td>
                                           	</tr>
	                            </table>
                            	<input type='hidden' name='student_code' value='<?php echo $student_code; ?>'>
                                <a  target='_blank' href="<?php echo base_url() . "index.php/fee/generatePrint?student_code=".$student_code; ?>" class="btn btn-primary align-Right " style='float:right;'  role="button">
	                                Print
								</a>
                            
                            </form>
                           <?php
                           if(validation_errors()){
                                echo "<span style='color:red;'><b>".validation_errors()."</b></span>";
                           }
                         }
                            
                        }else {
                                echo "<div>No record found!</div>";
                        }
                           ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view("footer"); ?>          
    </body>
</html>

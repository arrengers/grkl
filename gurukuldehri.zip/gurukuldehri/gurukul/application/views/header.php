<?php

/*function getBaseUrl() {
    return "http://localhost/training_platform_backend/";
}*/

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Gurukul</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="<?php echo base_url().'assets/css/taskbuilder.css'; ?>">
        <link rel="stylesheet" href="<?php echo base_url().'assets/css/libs/bootstrap.min.css'; ?>">
        <link rel="stylesheet" href="<?php echo base_url().'assets/css/libs/dataTables.bootstrap.min.css';?>">
        <script src="<?php echo base_url().'assets/js/libs/jquery.min.js'; ?>"></script>
        <script src="<?php echo base_url().'assets/js/libs/bootstrap.min.js';?>"></script>
        <!-- script src="<?php echo base_url().'assets/js/libs/dataTables.bootstrap.min.js'?>"></script-->
        <script src="<?php echo base_url().'assets/js/libs/datatables.min.js'?>"></script>        
        <script src="<?php echo base_url().'assets/js/libs/jquery.dataTables.min.js'?>"></script>
        <script src="<?php echo base_url().'assets/js/libs/jquery-1.12.4.js'; ?>"></script>

       <!-- 
       <script type="text/javascript">
            $(document).ready(function () {
            	$('#example').DataTable();
            });
       </script>
       -->
<style>
.data-container{
    border: 1px solid black;
    border-radius: 5px;
    padding: 10px 10px 10px 10px;
    min-height: 500px;
}    

.success_message{
	font-width:bold;
	color:green;
}
.error_message{
	font-width:bold;
	color:red;
}
</style>
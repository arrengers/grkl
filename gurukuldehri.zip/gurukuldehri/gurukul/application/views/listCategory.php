<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">
        
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend style="height: 50px;">
                                <span>Category List</span>
                                <a class='btn btn-primary' style='float:right' href="<?php echo base_url() . 'index.php/course/updateCategory?action=add'; ?>">Add New Category</a>
                            </legend>


                            <table id="example" class="table table-striped">
                                <thead>
                                    <tr class='table-striped'>
                                        <th>#</th>
                                        <th>Category Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (isset($categoryDetails)) {
                                        $i = 0;
                                        foreach ($categoryDetails as $category) {
                                            $i++;
                                            ?>
                                            <tr>
                                                <td><?php echo $i; ?></td>
                                                <td><a href='<?php echo base_url() . "index.php/course/updateCategory?action=edit&category_id=" . $category['category_id']; ?>'><?php echo $category['category_name']; ?></a></td>
                                                <td><button class="btn btn-sm btn-warning">Remove</button></td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>


                        </div>
                    </div>

                </div>

            </div>
        </div>



    </body>
</html>

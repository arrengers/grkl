<?php
$access = $this->session->userdata('access');
$access = explode(',', $access);
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">

        <ul class="nav" id="side-menu">

            <?php if (in_array('Attendance', $access)) { ?>
                <li>
                    <a href="#"><i class="fa fa-sitemap fa-fw"></i>Attendance<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="<?php echo base_url() ?>index.php/attendance/teacherAttendance">Teacher</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url() ?>index.php/attendance/markStudentAttendance">Student</a>
                        </li>
                    </ul>
                </li>
                <?php
            }
            if (in_array('Fee', $access)) {
                ?>
                <li>
                    <a href="#"><i class="fa fa-sitemap fa-fw"></i>Fee<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <?php
                        if (in_array('Feeupdation', $access)) {
                        ?>
                        <li>
                            <a href="<?php echo base_url() ?>index.php/fee/updateFee?action=add">Update Fee</a>
                            <!-- a href="/training_platform_backend/index.php/course/addCourse?action=add">Add New Course</a-->
                        </li>
                        <?php 
                        }
                        if (in_array('Feecollection', $access)) {
                        ?> 
                        <li>
                            <a href="<?php echo base_url() ?>index.php/fee">Collect Fee</a>
                            <!--a href="/training_platform_backend/index.php/course">Courses List</a-->
                        </li>
                        <?php 
                        }
                        ?> 
                    </ul>
                </li>
                <?php
            }
            if (in_array('Report1', $access)) {
                ?>
                <li>
                    <a href="#"><i class="fa fa-sitemap fa-fw"></i>Report<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="/training_platform_backend/index.php/course/updateCourseActivities?action=add">Teacher Attandence</a>
                        </li>
                        <li>
                            <a href="/training_platform_backend/index.php/course/updateCourseActivities?action=add">Student Attandence</a>
                        </li>
                        <li>
                            <a href="/training_platform_backend/index.php/course/listActivity">Student Fee due</a>
                        </li>
                    </ul>
                </li>
                <?php
            }
            if (in_array('StudentMgmt1', $access)) {
                ?>
                <li class="<?php echo @$active; ?>">
                    <a href="#"><i class="fa fa-sitemap fa-fw"></i>Student Management<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="/training_platform_backend/index.php/task" >Add/ Edit Student</a>
                        </li>
                        <li>
                            <a href="/training_platform_backend/index.php/task/assignTask">Assign Tasks</a>
                        </li>
                    </ul>
                </li>
                <?php
            }
            if (in_array('Users1', $access)) {
                ?>
                <li>
                    <a href="#"><i class="fa fa-sitemap fa-fw"></i> Users<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="/training_platform_backend/index.php/signin/get_users">Users List</a>
                        </li>
                        <li>
                            <a href="/training_platform_backend/index.php/signin/add_user?action=add">Add User</a>
                        </li>
                        <li>
                            <a href="/training_platform_backend/index.php/signin/import_csv_users">Import Users</a>
                        </li>
                        <li>
                            <a href="/training_platform_backend/index.php/signin/manage_groups">Manage Groups</a>
                        </li>
                    </ul>
                </li>

            <?php } ?>

        </ul>
    </div>
</div>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">


        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend style="height: 50px;">
                                <span>Add New Category</span>
                                <a href="<?php echo base_url() . "index.php/course/listCategory"; ?>" class="btn btn-default align-Right" style='float:right; margin: 10px;'  role="button">Back</a>
                            </legend>

                            <form method="post" action='<?php echo base_url() . "index.php/course/updatecategory"; ?>'>
                                <!-- Text input-->
                                <div class="form-group">
                                    <label class="control-label" for="textinput">Category Name</label>
                                    <input type="text" style="width: 500px;" placeholder="Category Name" name="category_name" value="<?php echo set_value('category_name', @$categoryDetails[0]['category_name']); ?>" class="form-control">
                                    <input type="hidden" name='category_id' id='category_id' value='<?php echo @$categoryDetails[0]['category_id']; ?>'>
                                    <input type="hidden" name='action' id='action' value='<?php echo @$action; ?>'>
                                </div>

                                <!-- Text input-->
                                <div class="form-group">
                                    <button class='btn btn-primary'>Submit</button>
                                </div>

                            </form>


                        </div>
                    </div>

                </div>

            </div>
        </div>



    </body>
</html>

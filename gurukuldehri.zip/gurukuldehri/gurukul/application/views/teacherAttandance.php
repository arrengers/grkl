<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Teacher Attendance</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">
        
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
        <script>

        $(document).ready(function() {
            $('.checkbox').click(function() {
                var id =  $(this).attr('id');
                var span_id = 'span'+id;
                if (!$(this).is(':checked')) {
                    $('#'+span_id).html('Absent');
                    $('#'+span_id).css('color','red');
                }else{
                    $('#'+span_id).text('Present');
                    $('#'+span_id).css('color','green');
                }
            });
        });        
        </script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">
                        
                              <form class="form-horizontal" method='post' action='<?php echo base_url() . "index.php/attendance/teacherAttendance"; ?>'>
                                <fieldset>
                                  <!-- Form Name -->
                                  <legend>Teacher Attendance</legend>
                        
                                  <!-- Text input-->
                                  <div class="form-group">
                                    <label class="col-sm-2" for="textinput">Date</label>
                                    <div class="col-sm-4">
	                                      <input type='date' name='attendance_date' min='<?php echo date('Y-m-d', strtotime(date('Y-m-d') .' -7 day')); ?>' value='<?php echo date('Y-m-d'); ?>' max='<?php echo date('Y-m-d'); ?>' required></input>
                                    </div>
                                  </div>
                        
                                  <div class="form-group">
                                    <div class="col-sm-10">
                                           <table id="example" class="table table-striped table-responsive" style='width: 100%;'>
                                                <thead>
                                                    <tr>
                                                        <th>Teacher ID</th>
                                                        <th>Tacher Name</th>
                                                        <th>Email</th>
                                                        <th>Attandence </th>
                                                    </tr>
												</thead>
												<?php if($teacherDetails){
												    foreach($teacherDetails as $tec){
												?>
                                                    <tr>
                                                        <td>
                                                        	<b><?php echo @$tec['teacher_code']; ?></b>
                                                        </td>
                                                        <td>
                                                        	<b><?php echo @$tec['first_name'].' '.$tec['middle_name'].' '.$tec['last_name']; ?></b>
                                                        </td>
                                                        <td>
                                                        	<b><?php echo @$tec['email']; ?></b>
                                                        </td>
                                                        <td style='width: 10%;'>
                                                        	<span class='pull-left'>
	                                                        	<input class='checkbox' type="checkbox" name='presence_status[]' id='status_<?php echo @$tec['teacher_id'];?>' checked='checked' value='<?php echo @$tec['teacher_code']?>'>
                                                        	</span>
                                                        	<span class='pull-right' style='color:green; font-weight:bold;;' id='spanstatus_<?php echo @$tec['teacher_id'];?>'>Present</span>
                                                        </td>
                                                    </tr>
                                                 <?php }
                                                    }?>
											</table>                                                    
                                    </div>
                                  </div>

                        
                                  <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-6">
                                      <div class="pull-right">
                                        <button type="submit" class="btn btn-primary">Submit Attendance</button>
                                      </div>
                                    </div>
                                  </div>

                                </fieldset>
                              </form>
                            </div><!-- /.col-lg-12 -->
                        </div><!-- /.row -->
                </div>
            </div>
        </div>
    </body>
</html>

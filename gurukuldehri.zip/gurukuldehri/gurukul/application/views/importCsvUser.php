<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">

        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend style="height: 50px;">
                                <span>Import Users</span>
                                <a href="<?php echo base_url() . "index.php/signin/get_users"; ?>" class="btn btn-default align-Right" style='float:right; margin: 10px;'  role="button">Back</a>

                            </legend>
                            <?php if (@$data_error == true || @$error == true) { ?>
                                <div class="alert alert-danger alert-dismissable fade in">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo @$data_error . @$error; ?>
                                </div>
                                <?php
                            }
                            if (@$user_data == true) {
                                ?>							
                                <div class="alert alert-success alert-dismissable fade in">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo 'Data is updated successfully!'; ?>
                                </div>
                            <?php } ?>  

                            <?php if (validation_errors() == true) { ?>
                                <div class="alert alert-danger alert-dismissable fade in">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo validation_errors(); ?>
                                </div>
                            <?php } ?>

                            <form class="form-horizontal" role="form" method='post' action='<?php echo base_url() . "index.php/signin/import_csv_users"; ?>' enctype="multipart/form-data">
                                <fieldset>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Group Name</label>
                                        <div class="col-sm-6">
                                            <input type="text" name='group_name' id='group_name' class="form-control" value='<?php echo set_value('group_name', @$role_access[0]['group_name']); ?>' required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Group Details</label>
                                        <div class="col-sm-6">
                                            <textarea type="text" name='group_details' id='group_details' class="form-control"><?php echo set_value('group_details', @$role_access[0]['group_details']); ?></textarea>
                                        </div>
                                    </div>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Upload Csv file</label>
                                        <div class="col-sm-6">
                                            <input type="file" name='user_csv' id='user_csv' placeholder="CSV File" class="form-control" required="required">
                                            <a href='<?php echo base_url() . "/data_format/import_user.csv"; ?>'>Download CSV format</a>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-sm-offset-2 col-sm-6">
                                            <div class="pull-right">
                                                <button type="submit" name='button' value= 'active' class="btn btn-primary">Save</button>
                                            </div>
                                        </div>
                                    </div>

                                </fieldset>
                            </form>
                            <div>
                                <table align='center' style='width:60%'>
                                    <?php
                                    if (is_array($user_data)) {
                                        echo "<tr>
									<td colspan='4' style='text-align:center; padding: 15px 15px 15px 15px;'><b>Data updated for following users </b><br></td>
									</tr>";
                                        echo "<tr style='border-bottom: 1px solid;'><td wdth='20%'>" . ucwords(str_replace('_', ' ', $user_data[0][0])) . "</td><td width='20%'>" . ucwords(str_replace('_', ' ', $user_data[0][1])) . "</td><td width='30%'>" . ucfirst($user_data[0][2]) . "</td><td width='30%'>" . ucfirst($user_data[0][3]) . "</td></tr>";
                                        unset($user_data[0]);
                                        foreach ($user_data as $userdata) {
                                        	$role = ($userdata[3]=='')?'Trainer':ucfirst($userdata[3]);
                                        	echo "<tr><td width='20%'>$userdata[0]</td><td width='20%'>$userdata[1]</td><td width='30%'>$userdata[2]</td><td width='30%'>".$role."</td></tr>";
                                        }
                                    }
                                    ?>
                                </table>
                            </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>



    </body>
</html>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">


        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_assignments.js"></script>
        <script>
        /*this code snippet need to move to javascript file assets/js/task_assignments.js, as this file is on server and changing every time not possible*/
        $(document).ready(function () {
        	suffleGroupUser();
	        $("#assignment_type").change(function () {
	        	suffleGroupUser();
	        });

	        function suffleGroupUser(){
	            var assignmentType = $("#assignment_type").val();
	            if (assignmentType === "user") {
	            	$("#selected_user_block").css( "display", "block" ) ;
	            	$("#selected_group_block").css( "display", "none" ); 
	            } else if (assignmentType === "group") {
	            	$("#selected_user_block").css( "display", "none" );
	            	$("#selected_group_block").css( "display", "block" ); 
                }
            }

	        $("#activity").change(function () {
	        	$("#package").val('----');
	        });

	        $("#package").change(function () {
	        	$("#activity").val('----');
	        });
            
        });

        function assignGroupTask() {
            
            var assignment_type = $("#assignment_type").val();
            var selectedUser = $("#select_user").val();
            var activityId = $("#activity").val();
            var parentTask = $("#user_task_list").val();
            var startDate = $("#start_date").val();
            var endDate = $("#end_date").val();
            var currentUser = $("#current_user").val();
            var package = $("#package").val();
            var select_group = $("#select_group").val();

            if(package=='----' && activityId=='----'){
				alert('Activity and Package both can\'t be blank, select atleast one field.');
				return false;
            }
            
            //return true;
            if (startDate.trim() === '' || endDate.trim() === '') {
                alert("Start Date and End date should not be empty");
            } else {
                var inputJson = {
                    user_id: selectedUser,
                    activity_id: activityId,
                    start_date: startDate,
                    current_user: currentUser,
                    end_date: endDate,
                    package: package,
                    select_group: select_group,
                    assignment_type:assignment_type
                };

                var url ='';
                console.log(inputJson);
                $.ajax(
                {
                    url: 'assignGroupTaskToUserGroup',
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify(inputJson),
                    datatype: 'json',
                    success: function (data) {
                        alert(data);
                    },
                    error: function (jqXHR, textStatus, errorThrown){
                        alert("Error in adding new task");
                    }
                });
            }
        }
        </script>
    </head>
    <body>
        <div id="wrapper">
            <?php $this->load->view("header_menu"); ?>  
            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8">
                            <form class="form-horizontal" role="form" method='post' action='<?php echo base_url() . "index.php/task/assignGroupTask"; ?>' enctype="multipart/form-data">
                                <fieldset>
                                    <!-- Form Name -->
                                    <legend>Assign Task</legend>
                                    <div style="padding: 30px;">

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="control-label" for="textinput">Select Assignment Type</label>
                                            <div> <?php echo $assginment_type_dropdown; ?></div>
                                        </div>


                                        <!-- Text input-->
                                        <div class="form-group" id='selected_user_block'>
                                            <label class="control-label" for="textinput">Select User</label>
                                            <div> <?php	echo $user_dropdown; ?> </div>
                                        </div>

                                        <!-- Text input-->
                                        <div class="form-group" id='selected_group_block'>
                                            <label class="control-label" for="textinput">Select Group</label>
                                            <div> <?php echo $group_dropdown; ?> </div>
                                        </div>

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="control-label" for="textinput">Select Activity</label>
                                            <div>
                                                <select class='form-control property_type' name='select_activity' id="activity">
                                                    <option value='----' selected='selected'>----</option>
                                                    <?php
                                                    foreach ($activities as $key => $activity) {
                                                        echo "<option value='{$activity["activity_id"]}' selected='selected'>[{$activity["category_name"]} | {$activity["type"]}] - {$activity["activity_name"]}</option>";
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>


                                        <!-- Text input-->
                                        <div class="form-group" id='user-task-list-block'>
                                            <label class="control-label" for="textinput">Select Package</label>
                                            <div><?php echo $package_dropdown; ?>
                                            </div>
                                        </div>

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="control-label" for="textinput">Start Date</label>
                                            <div>
                                                <input class="form-control" style="width: 300px;" id="start_date" name="start_date" placeholder="YYYY-MM-DD" type="text" />
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label" for="textinput">End Date</label>
                                            <div>
                                                <input class="form-control" style="width: 300px;" id="end_date" name="end_date" placeholder="YYYY-MM-DD" type="text" />
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label" for="textinput"></label>
                                            <div>
                                                <input type="hidden" value="<?php echo $current_user; ?>" id="current_user">
												<button type="button" class="btn btn-primary" onclick="assignGroupTask()">Assign Task</button>
                                                <!--button type="submit" name='button' class="btn btn-primary">Assign Task</button-->
                                            </div>
                                        </div>
                                    </div>
                                </fieldset>
                            </form>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </body>
</html>

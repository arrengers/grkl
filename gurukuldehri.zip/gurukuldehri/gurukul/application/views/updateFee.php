<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Gurukul</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">
        
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend style="height: 50px;">
                                <span>Manage Fee</span>
                                <!-- a href="<?php echo base_url() . "index.php/course/"; ?>" class="btn btn-default align-Right" style='float:right; margin: 10px;'  role="button">Back</a-->
                            </legend>

                            <form class="form" role="form" method="post" action='<?php echo base_url() . "index.php/fee/updateFee"; ?>'>
                                <div class="form-group">
                                    <label class="control-label" for="textinput">Choose Course</label>
                                    <?php echo $class_dropdown; ?>
                                </div>

                                <div class="form-group">
                                    <label class="control-label" for="textinput">Course Fee</label>
                                    <input type="text" style="width: 40%;" placeholder="Course Fee" name="course_fee" value="<?php echo set_value('course_fee', @$fee['fee']); ?>" class="form-control">
                                    <input type='hidden' name='action' id='action' value='<?php echo @$action; ?>'>
                                </div>

                                <!-- Text input-->
                                <div class="form-group">
                                    <button class='btn btn-primary'>Submit</button>
                                </div>
                            </form>

                        </div>
                        
                        <div class=''>
                        <?php 
                        if(@$class){
                        ?>
                        <table class="table table-striped">
                            <thead>
                              <tr>
                                <th>Course</th>
                                <th width='30%'>Fee</th>
                                <th width='20%'>Session</th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php 
                              foreach ($class as $cl){
                              ?>
                              <tr>
                                <td><?php echo $cl['name']?></td>
                                <td><?php echo $cl['fee']?></td>
                                <td>
                                	<?php
                                	   $year = (isset($cl['session_year_start']) && $cl['session_year_start']!='')? " - ". ($cl['session_year_start'] + 1) : "";
                                	   echo $cl['session_year_start'] . $year; 
                                	?></td>
                                <td><a href="<?php echo base_url() . "index.php/fee/updateFee?class_id=".$cl['class_id']?>"> 
                                	<button type="button" class="btn btn-info">Update</button>
                                </a></td>
                              </tr>
                              <?php 
                              }
                              ?>
                        	</tbody>
                        </table>
                        <?php     
                        }
                        ?>
                        </div>
                        
                        
                    </div>

                </div>

            </div>
        </div>
        <?php $this->load->view("footer"); ?>          
    </body>
</html>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">


        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-8">
                            <form class="form" role="form">


                                <fieldset>
                                    <!-- Form Name -->
                                    <legend>Assign Task</legend>

                                    <div style="padding: 30px;">

                                        show list of groups and user count and delete button for group - deleting group will delete group name

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="control-label" for="textinput">Select User</label>
                                            <div>
                                                <select class='form-control property_type' name='property_type' id="selected-user" onchange='updateUserTasks()'>

                                                    <?php
                                                    foreach ($users as $key => $user) {
                                                        echo "<option value='{$user["user_id"]}' selected='selected'>{$user["user_id"]} | {$user["user_name"]}</option>";
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="control-label" for="textinput">Select Group</label>
                                            <div>
                                                <select class='form-control property_type' name='property_type' id="selected-group" onchange='updateUserTasks()'>

                                                    <?php
                                                    foreach ($users as $key => $user) {
                                                        echo "<option value='{$user["user_id"]}' selected='selected'>{$user["user_id"]} | {$user["user_name"]}</option>";
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <label class="control-label" for="textinput"></label>
                                            <div>
                                                <button type="button" class="btn btn-primary" onclick="assignTask()">Assign Task</button>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label" for="textinput"></label>
                                            <div>
                                                <button type="button" class="btn btn-primary" onclick="assignTask()">Assign Task</button>
                                            </div>
                                        </div>

                                </fieldset>



                            </form>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </body>
</html>

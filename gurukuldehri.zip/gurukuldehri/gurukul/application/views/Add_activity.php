<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">

        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_history.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend style="height: 50px;">
                                <span>Manage Activity</span>
                                <a href="<?php echo base_url() . "index.php/course/listActivity"; ?>" class="btn btn-default align-Right" style='float:right; margin: 10px;'  role="button">Back</a>

                            </legend>

                            <form class="form-horizontal" role="form" method='post' action='<?php echo base_url() . "index.php/course/updateCourseActivities?course_id=" . @$course_id; ?>'>
                                <fieldset>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Activity Name</label>
                                        <div class="col-sm-6">
                                            <input type="text" name='activity_name' id='activity_name' placeholder="Activity Name" value='<?php echo set_value('activity_name', @$courseDetails[0]['activity_name']); ?>'class="form-control">
                                        </div>
                                    </div>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Activity Type</label>
                                        <div class="col-sm-6">
                                            <?php echo @$type_dropdown; ?>
                                        </div>
                                    </div>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Category</label>
                                        <div class="col-sm-6">
                                            <?php echo $category_dropdown; ?>
                                        </div>
                                    </div>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">Course Name</label>
                                        <div class="col-sm-6">
                                            <?php echo $course_dropdown; ?>
                                        </div>
                                    </div>

                                    <?php
                                    if ($_REQUEST['action'] == "edit") {
                                        ?>

                                        <div class="form-group">
                                            <label class="col-sm-2 control-label" for="textinput">Activity Properties</label>
                                            <div class="col-sm-6">

                                                <?php
                                                $properties = json_decode(@$courseDetails[0]['details'], TRUE);

                                                function printProperties($array, $offset) {
                                                    foreach ($array as $key => $value) {

                                                        $keyName = str_replace("_", " ", $key);
                                                        $keyName = ucwords($keyName);

                                                        if (is_array($value)) {
                                                            echo "$offset<strong>$keyName:</strong><br>";
                                                            printProperties($value, $offset . "&nbsp;&nbsp;&nbsp;&nbsp;");
                                                        } else {
                                                            echo "$offset<strong>$keyName:</strong> $value<br>";
                                                        }
                                                    }
                                                }

                                                echo "<pre>";
                                                printProperties($properties, "");
                                                echo "</pre>";
                                                ?>

                                            </div>
                                        </div>  

                                        <?php
                                    }
                                    ?>

                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="col-sm-2 control-label" for="textinput">JSON Details</label>
                                        <div class="col-sm-6">
                                            <textarea style="height: 200px;" name='details' id='details' class="form-control"><?php echo set_value('details', stripcslashes(@$courseDetails[0]['details'])); ?></textarea>
                                            <input type="hidden" name='activity_id' id='activity_id' value='<?php echo @$activity_id; ?>'>
                                            <input type="hidden" name='action' id='action' value='<?php echo @$action; ?>'>
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <div class="col-sm-offset-2 col-sm-6">
                                            <div class="pull-right">
                                                <button type="submit" name='button' value= 'draft'  class="btn">Draft</button>
                                                <button type="submit" name='button' value= 'active' class="btn btn-primary">Save</button>
                                            </div>
                                        </div>
                                    </div>

                                </fieldset>
                            </form>


                        </div>
                    </div>

                </div>

            </div>
        </div>



    </body>
</html>

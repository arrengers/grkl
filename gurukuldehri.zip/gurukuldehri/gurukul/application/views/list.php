<?php $this->load->view("header"); ?>  
<script type="text/javascript" src="<?php echo base_url(); ?>application/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>application/assets/js/libs/datatables.min.js"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>application/assets/css/libs/datatables.min.css"/>
<style>
td
{
 font-family:Verdana, Geneva, sans-serif;
}
</style>
</head>
   
<body>
    
                                
<div class="container">
	<table id="example"></table>
</div>                             
               
         

<script type="text/javascript" charset="utf-8">
$(document).ready(function() 
{
	$('#example').dataTable( {
		"aaData": [
		["PHP Data Object | PDO","http://www.codingcage.com/search/label/PDO"],
		["Object Oriented PHP","http://www.codingcage.com/search/label/PHP OOP"],
		["jQuery Tutorials","http://www.codingcage.com/search/label/jQuery"],
		["Ajax Tutorials","http://www.codingcage.com/search/label/Ajax"],
		["CRUD Tutorials","http://www.codingcage.com/search/label/CRUD"],
		["Pagination Tutorials","http://www.codingcage.com/search/label/Pagination"],
		["PHP MySQLi Tutorials","http://www.codingcage.com/search/label/MySQLi"],
		["HTML5 Tutorials","http://www.codingcage.com/search/label/HTML5"],
		["Pagination Tutorials","http://www.codingcage.com/search/label/Pagination"],
		["PHP MySQLi Tutorials","http://www.codingcage.com/search/label/MySQLi"],
		["PHP Data Object | PDO","http://www.codingcage.com/search/label/PDO"],
		["Object Oriented PHP","http://www.codingcage.com/search/label/PHP OOP"],
		["jQuery Tutorials","http://www.codingcage.com/search/label/jQuery"],
		["Ajax Tutorials","http://www.codingcage.com/search/label/Ajax"],
		["CRUD Tutorials","http://www.codingcage.com/search/label/CRUD"],
		["Pagination Tutorials","http://www.codingcage.com/search/label/Pagination"],
		["PHP MySQLi Tutorials","http://www.codingcage.com/search/label/MySQLi"],
		["HTML5 Tutorials","http://www.codingcage.com/search/label/HTML5"],
		["Pagination Tutorials","http://www.codingcage.com/search/label/Pagination"],
		["PHP MySQLi Tutorials","http://www.codingcage.com/search/label/MySQLi"],   
		["HTML5 Tutorials","http://www.codingcage.com/search/label/HTML5"]
		],
		"columns": [
			{ "title": "Article Title" },
		    { "title": "Tutorial Link" }
		]
	} );   
});

$('#example').addClass('table table-striped table-bordered');

</script>
<div class="clear"></div>
<?php $this->load->view("footer"); ?>  
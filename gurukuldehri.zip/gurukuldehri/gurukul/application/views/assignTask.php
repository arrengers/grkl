<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task Assignment</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">


        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/utils.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/task_assignments.js"></script>
    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-8">
                            <form class="form" role="form">


                                <fieldset>
                                    <!-- Form Name -->
                                    <legend>Assign Task</legend>

                                    <div style="padding: 30px;">

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="control-label" for="textinput">Select User</label>
                                            <div>
                                                <select class='form-control property_type' name='property_type' id="selected-user" onchange='updateUserTasks()'>

                                                    <?php
                                                    foreach ($users as $key => $user) {
                                                        echo "<option value='{$user["user_id"]}' selected='selected'>{$user["user_id"]} | {$user["user_name"]}</option>";
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>


                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="control-label" for="textinput">Select Activity</label>
                                            <div>
                                                <select class='form-control property_type' name='property_type' id="activity">

                                                    <?php
                                                    foreach ($activities as $key => $activity) {
                                                        echo "<option value='{$activity["activity_id"]}' selected='selected'>[{$activity["category_name"]} | {$activity["type"]}] - {$activity["activity_name"]}</option>";
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>


                                        <!-- Text input-->
                                        <div class="form-group" style="display: none;">
                                            <label class="control-label" for="textinput">Select Parent Task</label>
                                            <div>
                                                <select class='form-control property_type' name='property_type' id="user-task-list">
                                                </select>
                                            </div>
                                        </div>

                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="control-label" for="textinput">Start Date</label>
                                            <div>
                                                <input class="form-control" style="width: 300px;" id="start_date" name="start_date" placeholder="YYYY-MM-DD" type="text" />
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label" for="textinput">End Date</label>
                                            <div>
                                                <input class="form-control" style="width: 300px;" id="end_date" name="end_date" placeholder="YYYY-MM-DD" type="text" />
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label" for="textinput"></label>
                                            <div>
                                                <input type="hidden" value="<?php echo $current_user; ?>" id="current_user">
                                                <button type="button" class="btn btn-primary" onclick="assignTask()">Assign Task</button>
                                            </div>
                                        </div>
                                    </div>

                                </fieldset>



                            </form>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </body>
</html>

<script>



var containerLinechart = $('#line_char_data').val();
containerLinechart = JSON.parse(containerLinechart);
alert(containerLinechart);
Highcharts.chart('container_linechart', {
    title: {
        text: 'Photo Traning App timeline'
    },
    subtitle: {
        text: ''
    },
    yAxis: {
        title: {
            text: 'Bars'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },

    plotOptions: {
        series: {
            label: {
                connectorAllowed: false
            },
            pointStart: 10
        }
    },

    series: containerLinechart,

    responsive: {
        rules: [{
                condition: {
                    maxWidth: 500
                },
                chartOptions: {
                    legend: {
                        layout: 'horizontal',
                        align: 'center',
                        verticalAlign: 'bottom'
                    }
                }
            }]
    }
});
</script>
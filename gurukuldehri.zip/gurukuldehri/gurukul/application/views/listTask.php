<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Task List</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/libs/dataTables.bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo APPHOST; ?>assets/css/style.css">
        <link rel="shortcut icon" href="<?php echo APPHOST; ?>assets/favicon-48x48.ico">

        <script src="<?php echo APPHOST; ?>assets/js/libs/jquery.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/bootstrap.min.js"></script>

        <link href="<?php echo APPHOST; ?>assets/css/startmin.css" rel="stylesheet">
        <link href="<?php echo APPHOST; ?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo APPHOST; ?>assets/css/metisMenu.min.css" rel="stylesheet">

        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/moment.min.js"></script>
        <script type="text/javascript" src="<?php echo APPHOST; ?>assets/js/libs/daterangepicker.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo APPHOST; ?>assets/css/daterangepicker.css" />
        <script src="<?php echo APPHOST; ?>assets/js/libs/metisMenu.min.js"></script>
        <script src="<?php echo APPHOST; ?>assets/js/libs/startmin.js"></script>
        <style>
            .sr-only{
                position: relative !important;
            }

            .centered {
                text-align: center;
            }

        </style>

        <script type="text/javascript">

<?php
echo "var taskActivities = " . json_encode($taskactivities) . ";";
?>

            var curPage = <?php echo $curpage; ?>;
            function applyFilters(page) {

                var location = window.location.href.split("?")[0];
                location += "?page=" + page;
                $('.filterval').each(function (i, obj) {
                    var fvalue = $(obj).val();
                    if (fvalue !== "---") {
                        var fname = $(obj).data("mname");
                        location += "&" + fname + "=" + fvalue;
                    }
                });
                window.location.href = location;
            }

            function clearFilters() {
                var location = window.location.href.split("?")[0];
                location += "?page=1";
                window.location.href = location;
            }

            function resetActivityList() {

                $("#activity_id").html("");
                $("#activity_id").append("<option value='---'>--- Activity ---</option>");

                $.each(taskActivities, function (i, activity) {
                    if ($("#activity_type").val() === "---" || activity.activity_type === $("#activity_type").val()) {
                        $("#activity_id").append("<option value='" + activity.activity_id + "'>" + activity.activity_type + " | " + activity.activity_name + "</option>");
                    }
                });

            }

            $(document).ready(function () {

<?php
if (isset($_GET["activity_type"])) {
    echo "$('#activity_type').val('{$_GET["activity_type"]}');";
}

if (isset($_GET["task_status"])) {
    echo "$('#task_status').val('{$_GET["task_status"]}');";
}
if (isset($_GET["created_by"])) {
    echo "$('#created_by').val('{$_GET["created_by"]}');";
}
?>

                $('#activity_type').on('change', function () {
                    resetActivityList();
                });

                resetActivityList();

<?php
if (isset($_GET["activity_id"])) {
    echo "$('#activity_id').val('{$_GET["activity_id"]}');";
}
?>

            });

        </script>

    </head>
    <body>

        <div id="wrapper">

            <?php $this->load->view("header_menu"); ?>  

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-md-12">

                            <legend>Task List</legend>

                            <div class="panel">
                                <div class="panel-body">
                                    <select class="pull-left form-control task-filter filterval" data-mname="activity_type" id="activity_type">
                                        <option value="---">--- Task Type ---</option>
                                        <option value="validation">Validation</option>
                                        <option value="education">Education</option>
                                    </select>

                                    <select class="pull-left form-control task-filter filterval" data-mname="activity_id" id="activity_id">
                                        <option value="---">--- Activity ---</option>

                                        <?php
                                        foreach ($taskactivities as $activity) {
                                            echo "<option value='{$activity['activity_id']}'>{$activity['activity_type']} | {$activity['activity_name']}</option>";
                                        }
                                        ?>

                                    </select>

                                    <?php if (count($createdByList) > 0) { ?>

                                        <select class="pull-left form-control task-filter filterval" data-mname="created_by" id="created_by">
                                            <option value="---">--- Created By ---</option>

                                            <?php
                                            foreach ($createdByList as $createdBy) {
                                                echo "<option value='{$createdBy['user_id']}'>{$createdBy['user_name']}</option>";
                                            }
                                            ?>

                                        </select>

                                    <?php } ?>

                                    <select class="pull-left form-control task-filter filterval" data-mname="task_status" id="task_status">
                                        <option value="---">--- Status ---</option>
                                        <option value="assigned">Assigned</option>
                                        <option value="in progress">In Progress</option>
                                        <option value="in review">In Review</option>
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>

                                    <button class="btn btn-primary pull-left form-control task-filter" style="color: white; width: 100px;" onclick="applyFilters(1)">Search</button>
                                    <button class="btn btn-default pull-left form-control task-filter" style=" width: 100px;" onclick="clearFilters()">Clear</button>

                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="row" style="margin-top: 10px;">

                        <div class="col-md-12">

                            <table id="example5" class="table table-striped" width="800px">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Task Type</th>
                                        <th>Task</th>
                                        <th>Status</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Parent Task Name</th>
                                        <th>Created By</th>
                                        <th>Assignee</th>
                                        <th>Updated Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (@$tasks) {
                                        $i = 0;
                                        foreach ($tasks as $tas) {
                                            $i++;
                                            $taskStartDate = "";
                                            $activityName = @$tas['activity_name'];
                                            $taskType = ucfirst($tas['activity_type']);
                                            $status = @$tas['task_status'];

                                            $statusColor = "black";

                                            if ($status == "assigned") {
                                                $statusColor = "black";
                                            } else if ($status == "in progress") {
                                                $statusColor = "blue";
                                            } else if ($status == "in review") {
                                                $statusColor = "orange";
                                            } else if ($status == "completed") {
                                                $statusColor = "green";
                                            } else if ($status == "cancelled") {
                                                $status = "closed";
                                                $statusColor = "red";
                                            }

                                            $status = "<font color='$statusColor'>" . ucwords($status) . "</font>";


                                            if ($taskType == "Validation") {
                                                $taskType = "<b>$taskType</b>";
                                            } else {
                                                $taskType = "<i>$taskType</i>";
                                            }

                                            try {
                                                $taskStartDate = new DateTime($tas['task_start_date']);
                                                $taskStartDate = $taskStartDate->format('m/d/Y');
                                            } catch (Exception $e) {
                                                
                                            }

                                            $taskEndDate = "";

                                            try {
                                                $taskEndDate = new DateTime($tas['task_end_date']);
                                                $taskEndDate = $taskEndDate->format('m/d/Y');
                                            } catch (Exception $e) {
                                                
                                            }
                                            ?>
                                            <tr>
                                                <th scope="row"><?php echo $i; ?></th>
                                                <td><?php echo $taskType; ?></td>
                                                <td><a href='<?php echo base_url() . "index.php/course/taskHistoryUpdates?task_id=" . @$tas['task_id'];
                                            ?>'><?php echo $activityName; ?></a></td>
                                                <td><?php echo $status; ?></td>
                                                <td><?php echo $taskStartDate; ?></t        d>
                                                <td><?php echo $taskEndDate; ?></td>
                                                <td><?php echo @$tas['parent_task_name']; ?></td>
                                                <td><?php echo @$tas['created_by']; ?></        td>
                                                <td><?php echo @$tas['user_name']; ?></t        d>
                                                <td><?php echo @$tas['updated_date']; ?>        </td>
                                            </tr>
                                            <?php
                                        }
                                    } else {
                                        ?>
                                        <tr>
                                            <td colspan='10'>No task found for this user!</td>
                                        </tr>
                                    <?php }
                                    ?>
                                </tbody>
                            </table>

                            <div class='centered'>
                                <hr>
                                <ul class="pagination">

                                    <?php
                                    for ($i = $startpage; $i <= $endpage; $i++) {

                                        $active = "";
                                        if ($i == $curpage) {
                                            $active = " class='active' ";
                                        }

                                        echo "<li $active><a onclick='applyFilters($i)' href='#'>$i</a></li>";
                                    }
                                    ?>

                                </ul>

                            </div>	

                        </div>
                    </div>

                </div>

            </div>
        </div>
        <!-- Footer -->
        <?php $this->load->view("footer"); ?>          
    </body>
</html>

<style>
hr {
  height: 4px;
  margin: 15px 15px 15px 15px;
}
.hr-warning{
  background-image: -webkit-linear-gradient(left, rgba(210,105,30,.8), rgba(210,105,30,.6), rgba(0,0,0,0));
}
</style>
<br>

<div style='text-align:right; padding:0px 25px 10px 0px;'>
	<div>
		&copy; Copyright 2018 Gurukul Dehri - All Rights Reserved
	</div>
</div>
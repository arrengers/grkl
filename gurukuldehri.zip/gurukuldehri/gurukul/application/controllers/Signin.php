<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Signin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('user');
    }

    public function index() {
        $this->load->library('form_validation'); //loading this library for form validation
        $this->load->library('session');
        
        $data = null;

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($this->form_validation->run() == TRUE) {
            $userData['user_id'] = $this->input->post('username');
            $password = $this->input->post('password');
            $salt = $this->config->item('salt_value');
            $userData['password'] = hash('sha256', $password . $salt);
            //echo $userData['password'];

            $response = $this->user->login($userData, 'web');
            if ($response == 204 || $response == 500) {
                $data['msg'] = 'Username/Password is incorrect!';
            } else {
                $newdata = array(
                    'user_id' => $response['user_id'],
                    'token' => $response['token'],
                    'token_expiration_time' => $response['token_expiration_time'],
                    'user_name' => $response['user_name']
                );

                $role_access = $this->user->get_role_access($response['user_id']);

                if ($role_access) {
                    $newdata['access'] = $role_access["access"];
                    $newdata['role'] = $role_access["role"];
                }

                $this->session->set_userdata($newdata);
                redirect(base_url() . "index.php/dashboard/index", 'location');
            }
        }

        $this->load->view('signView', $data);
    }

    /*
     * Function to let user logout and delete the user session
     */

    public function logout() {
        $newdata = array('user_id', 'token', 'token_expiration_time', 'access', 'user_name');
        $this->session->unset_userdata($newdata);
        //redirect(base_url() . "index.php/signin/index", 'location');
        redirect("http://gurukuldehri.com", 'location');
    }

    /*
     * Function to list all users
     */

    function get_users() {
        if (isset($_GET['page']) & !empty($_GET['page'])) {
            $data['curpage'] = $curpage = $_GET['page'];
        } else {
            $data['curpage'] = $curpage = 1;
        }
        $perpage = 10;
        $pagination['start'] = ($curpage * $perpage) - $perpage;
        $pagination['end'] = '10';

        $totalres = $this->user->get_all_user();
        //$totalres = count($totalres);

        $data['endpage'] = ceil($totalres / $perpage);
        $data['startpage'] = 1;
        $data['nextpage'] = $curpage + 1;
        $data['previouspage'] = $curpage - 1;

        $data['role_access'] = $this->user->get_user_details($pagination);
        $this->load->view('listUsers', $data);
    }

    /*
     * function to add users
     */

    function add_user() {
        $data = null;
        $this->load->library('form_validation'); //loading this library for form validation
        $data['success'] = $this->input->get('success');
        $data['user_id'] = $user_id = $this->input->get_post('user_id');

        $action = $this->input->get_post('action');
        $data['action'] = ($action == '') ? 'add' : $action;

        $this->form_validation->set_rules('first_name', 'First Name', 'required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'required');
        $this->form_validation->set_rules('email', 'E-mail', 'valid_email');
        $this->form_validation->set_rules('role', 'Role', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == TRUE) {
            $first_name = $this->input->post('first_name');
            $last_name = $this->input->post('last_name');
            $userData['email'] = $this->input->post('email');
            $password = $this->input->post('password');
            $roleData['role'] = $this->input->post('role');
            $userData['user_name'] = ucwords($first_name) . ' ' . ucwords($last_name);
            $salt = $this->config->item('salt_value');

            if ($action == 'add') {
                $userData['user_id'] = strtolower($first_name) . rand(100, 999);
                $roleData['user_id'] = $userData['user_id'];
                $userData['password'] = hash('sha256', $password . $salt);
                //$userData['password'] = hash('sha256', '111' . $salt);
                $userinsert = $this->user->insert($userData);
                $roleinsert = $this->user->insertUserRole($roleData, $action);
                if ($userinsert == true && $roleinsert == true)
                    redirect(base_url() . "index.php/signin/add_user?&action=add&success=1", 'location');
                else
                    redirect(base_url() . "index.php/signin/add_user?&action=add&success=2", 'location');
            }

            if ($action == 'edit') {
                $userData['password'] = hash('sha256', $password . $salt);
                //$userData['password'] = hash('sha256', '111' . $salt);
                $userupdate = $this->user->update($userData, $user_id);
                $roleupdate = $this->user->insertUserRole($roleData, $action, $user_id);
                if ($userupdate == true && $roleupdate == true)
                    redirect(base_url() . "index.php/signin/add_user?user_id=$user_id&action=edit&success=1", 'location');
                else
                    redirect(base_url() . "index.php/signin/add_user?user_id=$user_id&action=edit&success=2", 'location');
            }
        }
        if ($user_id != '') {
            $role_access = $this->user->get_user_details('', $user_id);
            $username = (isset($role_access[0]['user_name'])) ? explode(' ', $role_access[0]['user_name']) : '';
            if (is_array($username)) {
                $role_access[0]['first_name'] = ucfirst($username[0]);
                $role_access[0]['last_name'] = ucfirst($username[1]);
            }
            $data['role_access'] = $role_access;
        }

        //creating Role dropdown
        $role_array = array('auditor' => 'Auditor', 'trainer' => 'Trainer', 'admin' => 'Admin');
        $css = 'id="role" class="form-control"';
        $selected_type = (isset($role_access[0]['role'])) ? $role_access[0]['role'] : '';
        unset($role_access);
        $data['role_dropdown'] = form_dropdown('role', $role_array, $selected_type, $css);

        $this->load->view('addUser', $data);
    }

    /*
     * Function to import user from csv 	 
     */

    function import_csv_users() {
        $data['user_data'] = $user_role = $error = '';
        $role_array = array('trainer', 'admin');
        
        
        if ($this->input->post()) {
        	$this->load->library('form_validation'); //loading this library for form validation
        	$this->form_validation->set_rules('group_name', 'Group Name', 'required');
        	if ($this->form_validation->run() == TRUE) {

        		//$group_name= $this->input->post('group_name');
        		//$group_details= $this->input->post('group_details');
        		$file = $_FILES['user_csv'];
        		if ($file['name'] != ''){ //validating if file uploaded

        			$filename = explode('.', $file['name']);
        			$filext = end($filename);
        			if (strtolower($filext) == 'csv') { //validating if file type is correct
        				
        				//Getting data from and creating group
        				$group['group_id']= 'grp'. rand(100000, 999999);
        				$group['group_name']= $this->input->post('group_name');
        				$group['group_details']= $this->input->post('group_details');
        				$group['created_date']=date('Y-m-d H:i:s');
        				$group_id = $this->user->create_group($group);
        				
        				$upload_path = $this->config->item('csv_upload_path');
        				$newname = $upload_path . rand(100000, 999999) . '.' . $filext;
        				
        				if (move_uploaded_file($_FILES['user_csv']['tmp_name'], $newname)) {
        					
        					$file_handle = fopen($newname, 'r');
        					$line_of_text = fgetcsv($file_handle, 1024);
        					
        					if (($line_of_text[0] == 'first_name') && ($line_of_text[1] == 'last_name') && ($line_of_text[2] == 'email') && ($line_of_text[3] == 'role')) {
        						$user_data[] = $line_of_text;
        						
        						$salt = $this->config->item('salt_value');
        						$i = 0;
        						$query = $role_query = $group_query = '';
        						while (($line_of_text = fgetcsv($file_handle, 0, ",")) !== FALSE) {
        							$user_id = strtolower($line_of_text[0]) . rand(100, 999);
        							$user_name = ucwords($line_of_text[0]) . ' ' . ucwords($line_of_text[1]);
        							$password = hash('sha256', rand(1111, 9999) . $salt);
        							
        							if (!filter_var($line_of_text[2], FILTER_VALIDATE_EMAIL) === false) {
        								//preparing data to create user
        								$query .= "('" . $user_id . "','" . $user_name . "','" . $line_of_text[2] . "','" . $password . "'), ";
        								$user_data[] = $line_of_text;
        								
        								//preparing to create role for user craeted above
        								$user_role = (in_array($line_of_text[3], $role_array)) ? $line_of_text[3] : 'trainer';
        								$role_query .= "('" . $user_id . "','" . $user_role . "'), ";
        								
        								//preparing data to assign user to given group.
        								$group_query .= "('" . $group_id. "','" . $user_id . "'), ";
        								
        							} else {
        								$error .= "Log in cannot be created for user <b>$line_of_text[0]</b>, as his email($line_of_text[2]) is not a valid email address<br>";
        							}
        						}
        						$query = substr($query, 0, -2);
        						if ($query!=''){
        							//creating user
        							$sql = "INSERT INTO users(`user_id`,`user_name`,`email`,`password`) VALUES" . $query . ";";
        							$result = $this->user->create_users_from_csv($sql);
        							
        							//assigning role
        							$role_query = substr($role_query, 0, -2);
        							$role_sql = "INSERT INTO user_roles(`user_id`,`role`) VALUES" . $role_query . ";";
        							$result = $this->user->create_users_from_csv($role_sql);
        							
        							//assigning group
        							$group_query= substr($group_query, 0, -2);
        							$group_sql = "INSERT INTO `group_users` (`group_id`, `user_id`) VALUES " . $group_query. ";";
        							$result = $this->user->create_users_from_csv($group_sql);
        						
        							$data['user_data'] = $user_data;
        							$data['data_error'] = $error;
        							}
        						} else {
        							$data['error'] = 'Incorrect template format!';
        						}
        						fclose($file_handle);
        					}
        			}else {
        				$data['error'] = 'Only csv file type accepted.';
        			}
        		}else{
        			$data['error'] = 'Upload Csv file field is required. ';
        		}
        	}
        }
        $this->load->view('importCsvUser', $data);
    }

    function manage_groups() {
        $data = array();
        $this->load->view('createGroup', $data);
    }

}

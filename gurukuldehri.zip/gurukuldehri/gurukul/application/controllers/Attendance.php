<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('gurukul_model'); //course_api_model
    }

    public function index() {
        $data['success'] = $this->input->get('success');
        $data['courseDetails'] = $this->course_model->getCourse();
        $this->load->view('listCourses', $data);
    }

    function teacherAttendance() {
        $data = array();
        $this->load->library('form_validation'); //loading this library for form validation
        $data['teacherDetails'] = $teacherDetails =  $this->gurukul_model->getTeacherDetails();

        $this->form_validation->set_rules('date', 'Date', 'required');
        if($this->input->post()){
            $date = $this->input->post("attendance_date");
            $status = $this->input->post("presence_status");
            $total_teacher = count($teacherDetails);
            for($i =0 ; $i<$total_teacher; $i++){
                if(in_array($teacherDetails[$i]['teacher_code'],$status)){
                    $this->gurukul_model->submitTeacherAttendance($teacherDetails[$i]['teacher_id'],$date,'P');
                }else{
                    $this->gurukul_model->submitTeacherAttendance($teacherDetails[$i]['teacher_id'],$date,'A');
                }
            }
            redirect(base_url() . "index.php/attendance/teacherAttendance?success=" . $success, 'location');
        } 
        $this->load->view('teacherAttandance', $data);
    }

        
    function markStudentAttendance() {
        $data = array();
        $this->load->library('form_validation'); //loading this library for form validation
        $data['class_id'] = $class_id = $this->input->post("class_id");
        $data['attendance_date'] = $date = $this->input->post("attendance_date");
        
        if($class_id){
            $data['studentDetails'] = $studentDetails =  $this->gurukul_model->getStudentDetailsByClass(NULL,$class_id);
        }else 
            $data['studentDetails'] = null;
        
        $this->form_validation->set_rules('date', 'Date', 'required');
        if($this->input->post('presence_status')){
            $status = $this->input->post("presence_status");
            $total_teacher = count($studentDetails);
            for($i =0 ; $i<$total_teacher; $i++){
                if(in_array($studentDetails[$i]['student_code'],$status)){
                    $this->gurukul_model->markStudentAttendance($studentDetails[$i]['student_id'],$date,'P',$class_id);
                }else{
                    $this->gurukul_model->markStudentAttendance($studentDetails[$i]['student_id'],$date,'A',$class_id);
                }
            }
            redirect(base_url() . "index.php/attendance/markStudentAttendance?success=" . $success, 'location');
        }

        //class dropdown
        $data['class']=$class = $this->gurukul_model->getCourse();
        $class_array = array();
        $css = 'id="class_id" class="form-control property_type " style="width: 40%;" onChange="some_function();"';
        foreach ($class as $cat) {
            $class_array[$cat['class_id']] = $cat['name'];
        }
        $data['class_dropdown'] = form_dropdown('class_id', $class_array, $class_id, $css);
        
        $this->load->view('studentAttandance', $data);
    }
    
    
    /*
     * function to delete courses
     */

    public function deleteCourse() {
        $data['course_id'] = $this->input->get_post("course_id");
        $this->course_model->deleteCourse($data);
        $this->load->view('listCourses');
    }

    public function listActivity() {
        $data['activityList'] = $this->course_model->getCourseActivities();
        $this->load->view('listCourseActivities', $data);
    }

    public function updateCourseActivities() {

        $data = array();
        $this->load->library('form_validation');

        $data['action'] = $action = $this->input->get_post('action');
        $data['activity_id'] = $activity_id = $this->input->get_post("activity_id");
        $data['course_id'] = $course_id = $this->input->get_post("course_id");
        $condition = array('activity_id' => $activity_id);
        $data['courseDetails'] = $courseDetails = $this->course_model->getCourseActivities($condition);

        //creating category dropdown
        $categories = $this->course_model->getCategories();
        $categories_array = array();
        $css = 'id="category_id" class="form-control property_type" onChange="some_function();"';

        foreach ($categories as $cat) {
            $categories_array[$cat['category_id']] = $cat['category_name'];
        }

        $selected_value = (isset($courseDetails[0]['category_id'])) ? $courseDetails[0]['category_id'] : '';
        $data['category_dropdown'] = form_dropdown('category_id', $categories_array, $selected_value, $css);

        //creating courses dropdown
        $courses = $this->course_model->getCourse();
        $courses_array = array();
        $css = 'id="course_id" class="form-control property_type" onChange="some_function();"';

        foreach ($courses as $cour) {
            $courses_array[$cour['course_id']] = $cour['course_name'];
        }

        $selected_value = (isset($courseDetails[0]['course_id'])) ? $courseDetails[0]['course_id'] : '';
        $data['course_dropdown'] = form_dropdown('course_id', $courses_array, $selected_value, $css);

        //creating activity type dropdown
        $activity_array = array('education' => 'Education', 'validation' => 'Validation');
        $css = 'id="type" class="form-control property_type"';
        $selected_type = (isset($courseDetails[0]['type'])) ? $courseDetails[0]['type'] : '';
        $data['type_dropdown'] = form_dropdown('type', $activity_array, $selected_type, $css);


        $this->form_validation->set_rules('activity_name', 'Activity Name', 'required');
        $this->form_validation->set_rules('type', 'Activity Type', 'required');
        $this->form_validation->set_rules('category_id', 'Category', 'required');
        $this->form_validation->set_rules('course_id', 'Course', 'required');
        $this->form_validation->set_rules('details', 'Json Details', 'required');

        if ($this->form_validation->run() == TRUE) {
            $data_insert['activity_name'] = $this->input->post("activity_name");
            $data_insert['type'] = $this->input->post("type");
            $data_insert['category_id'] = $this->input->post("category_id");
            $data_insert['course_id'] = $this->input->post("course_id");
            $data_insert['details'] = $this->input->post("details");
            $data_insert['activity_status'] = $this->input->post("button");

            //$data_insert['course_id'] = $course_id;

            if ($action == 'add') {
                $data_insert['activity_id'] = 'ca' . rand(10000, 99999);
                $result = $this->course_model->addCourseActivities($data_insert);
            } else {
                $result = $this->course_model->updateCourseActivities($data_insert, $activity_id);
            }


            if ($result)
                $success = 'success';
            else
                $success = 'error';

            redirect(base_url() . "index.php/course/listActivity?course_id=" . $course_id . "&success=" . $success, 'location');
        }
        $this->load->view('Add_activity', $data);
    }

    public function deleteCourseActivities() {

        $data['task_id'] = $this->input->get_post("course_id");
        $this->course_model->deleteCourseActivities($data);
        $this->load->view('listCourseActivities');
    }

    public function listCategory() {
        $this->session->flashdata('success_msg');
        $data = array();
        $data['success'] = $this->input->get('success');
        $data['categoryDetails'] = $this->course_model->getCategories();

        //print_r($data['categoryDetails']);
        $this->load->view('listCategory', $data);
    }

    /*
     * Function for addting/edit category 
     */

    public function updateCategory() {
        $data = array();
        $this->load->library('form_validation');
        $data_insert['category_id'] = $category_id = $this->input->get_post('category_id');
        $data['action'] = $action = $this->input->get_post("action");
        if ($action == 'add') {
            $getCategories = $this->course_model->getCategories($category_id);
        }

        $this->form_validation->set_rules('category_name', 'Category Name', 'required');

        if ($this->form_validation->run() == TRUE) {
            $data_insert['category_name'] = $this->input->get_post("category_name");
            if ($action === 'add') {
                //$categories_count = $this->course_model->countRows('categories');
                //$categories_count = ($categories_count == true) ? $categories_count + 1 : 1;
                $data_insert['category_id'] = 'cat' . str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
                $result = $this->course_model->addCategory($data_insert);
            } else {
                $result = $this->course_model->updateCategory($data_insert);
            }

            if ($result) {
                //$this->session->set_flashdata('success_msg', 'Your data updated successfully!');
                $update = 'success';
            } else {
                $update = 'error';
                //$this->session->set_flashdata('error_msg', 'Proble, updating your data successfully. Please try after sometime.');
            }
            redirect(base_url() . "index.php/course/listCategory?success=" . $update, 'location');
        }
        $this->load->view('updateCategory', $data);
    }

    public function listTask() {
        $user_id = $this->input->get_post('user_id');
        $this->load->model('task_model');
        $data = array();
        $data['tasks'] = $this->task_model->getTasks($user_id);
        $this->load->view('listTask', $data);
    }

    public function taskHistoryUpdates() {
        $this->load->model('task_model');
        $data['task_id'] = $task_id = $this->input->get_post('task_id');
        $data['history'] = $this->task_model->getTasks_History($task_id);
        $data['history_status'] = $this->task_model->getTasksDetailsByid($task_id);

        $data['photo_activity'] = false;
        $activityDetails = json_decode(@$data['history_status'][0]['details'], TRUE);

        if ($activityDetails && isset($activityDetails['activity_type'])) {

            $photoActivities = array('ARPhotoTraining_validation', 'RealShelfPhotoTraining_validation');
            if (in_array($activityDetails['activity_type'], $photoActivities)) {
                $data['photo_activity'] = TRUE;
            }
        }

        $this->load->view('taskHistoryUpdates', $data);
    }

    /*
     * Function to approve task
     */

    public function approveTask() {
        $this->load->model('task_model');
        $task_id = $this->input->get_post('task_id');
        $status = $this->input->get_post('status');
        if ($status == 'approve') {
            $data['task_status'] = 'completed';
            //$taskHistory= $this->task_model->updateTaskHistory($data,$task_id);
            //$update_id = $this->task_model->taskCount() + 1;
            $dataHidtory['update_id'] = str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
            $dataHidtory['task_id'] = $task_id;
            $dataHidtory['update_type'] = 'status';
            $dataHidtory['updated_date'] = date("Y-m-d H:i:s"); //use 24-hr format
            $tasks = $this->task_model->getTasksDetailsByid($task_id);
            $content = array("assignee" => $tasks[0]['user_name'], "current_status" => 'completed', "previous_status" => @$tasks[0]['task_status']);
            $dataHidtory['content'] = json_encode($content);
            $tasks = $this->task_model->taskHistoryUpdate($dataHidtory);
            $result = $this->task_model->updateTask($data, $task_id);

            if ($result)
                echo $success = 'success';
            else
                echo $success = 'error';
        } else
            echo 'error';
    }

    /*
     * Function to close task
     */

    public function cancelTask() {
        $this->load->model('task_model');
        $task_id = $this->input->get_post('task_id');
        $status = $this->input->get_post('status');
        if ($status == 'close') {
            $data['task_status'] = 'cancelled';
            //$update_id = $this->task_model->taskCount() + 1;
            $dataHidtory['update_id'] = str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
            $dataHidtory['task_id'] = $task_id;
            $dataHidtory['update_type'] = 'status';
            $dataHidtory['updated_date'] = date("Y-m-d H:i:s"); //use 24-hr format
            $tasks = $this->task_model->getTasksDetailsByid($task_id);
            $content = array("assignee" => $tasks[0]['user_name'], "current_status" => 'cancelled', "previous_status" => @$tasks[0]['task_status']);
            $dataHidtory['content'] = json_encode($content);
            $tasks = $this->task_model->taskHistoryUpdate($dataHidtory);
            $result = $this->task_model->updateTask($data, $task_id);

            if ($result)
                echo $success = 'success';
            else
                echo $success = 'error';
        } else
            echo 'error';
    }

    /*
     * Function to close task
     */

    public function reassignTask() {
        $this->load->model('task_model');
        $task_id = $this->input->get_post('task_id');
        $end_date = $this->input->get_post('end_date');

        $dataHidtory['update_id'] = str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
        $dataHidtory['task_id'] = $task_id;
        $dataHidtory['update_type'] = 'status';
        $dataHidtory['updated_date'] = date("Y-m-d H:i:s"); //use 24-hr format
        $tasks = $this->task_model->getTasksDetailsByid($task_id);
        $content = array("assignee" => $tasks[0]['user_name'], "current_status" => 'assigned', "previous_status" => @$tasks[0]['task_status']);
        $dataHidtory['content'] = json_encode($content);

        $tasks = $this->task_model->taskHistoryUpdate($dataHidtory);
        $data['task_status'] = 'assigned';
        $data['end_date'] = $end_date;
        $result = $this->task_model->updateTask($data, $task_id);

        if ($result)
            echo 'Task re-assignment is done!';
        else
            echo 'An error occured while re-assigning the task!';
    }

    public function getCourseAjax($id = 0) {
        $this->load->model('course_model');
        $data['courseDetails'] = $this->course_model->getCourse();
        die(json_encode($data['courseDetails']));
    }

    public function assignTask() {
        $this->load->model('user');
        $data['users'] = $this->user->getRows();
        $this->load->view('Assign_task', $data);
    }

    /*
     * 
     */

    public function addMessage() {
        $message = $this->input->get_post('message');
        $task_id = $this->input->get_post('task_id');
        $user_name = $this->input->get_post('user_name');

        $this->load->model('task_model');
        $dataHidtory['update_id'] = str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
        $dataHidtory['task_id'] = $task_id;
        $dataHidtory['update_type'] = 'message';
        $dataHidtory['updated_date'] = date("Y-m-d H:i:s"); //use 24-hr format
        //$tasks= $this->task_model->getTasksDetailsByid($task_id);
        //$content= array("assignee"=>$tasks[0]['user_name'],"current_status"=>'assigned',"previous_status"=>@$tasks[0]['task_status']);
        $content = array("sender" => $user_name, "message" => $message); //	{"sender": "test3", "message": "3"}
        $dataHidtory['content'] = json_encode($content);
        $tasks = $this->task_model->taskHistoryUpdate($dataHidtory);
        if ($tasks == true) {
            echo 'Messaged successfully!';
        } else {
            echo 'Message failed!';
        }
    }

}

?>
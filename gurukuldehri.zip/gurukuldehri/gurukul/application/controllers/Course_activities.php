<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Course_activities extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
		$this->load->model('course_activities_model');	//course_api_model
	}
	
	
}
?>
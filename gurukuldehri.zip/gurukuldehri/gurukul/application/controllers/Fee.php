<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Fee extends CI_Controller {
   // var $user_id=null;
    public $user_id;
    public function __construct() {
        parent::__construct();
        //$this->load->model('course_model'); //course_api_model
        $this->load->model('gurukul_model'); //course_api_model
        $this->user_id = $this->session->userdata('user_id');
    }

    public function index() {
        $data['success'] = $this->input->get('success');
        //DS01012018001
        $this->load->library('form_validation'); //loading this library for form validation
        $search_data['student_id'] = $student_id = $this->input->post('student_id');
        $search_data['name'] = $this->input->post('student_name');
        $search_data['class'] = $this->input->post('student_class');
        if($this->input->post()){
            $data['studentDetails'] = $this->gurukul_model->searchStudent($search_data);
        }
        //print_r($data['studentDetails']);exit();
        $this->load->view('searchStudent', $data);
    }

    function updateFee() {
        $data = array();
        $data['action'] = $action = $this->input->get_post("action");
        $this->load->library('form_validation'); //loading this library for form validation
        $data['class_id'] = $class_id = $this->input->get_post('class_id');
        if($class_id){
            $this->form_validation->set_rules('course_fee', 'Course Fee', 'required');
            if ($this->form_validation->run() == TRUE) {
                $data_insert['course_fee'] = $this->input->get_post("course_fee");
                if ($action == 'add') {
                    $data_insert['course_id'] = strtolower();
                    $update = $this->course_model->addCourse($data_insert);
                } else {
                    $data_insert['class_id'] = $class_id;
                    $update = $this->gurukul_model->updateCourse($data_insert);
                }
                if ($update)
                    $success = 'success';
                else
                    $success = 'error';
    
                redirect(base_url() . "index.php/fee/updateFee?success=" . $success, 'location');
            }
        }
        
        //class dropdown
        $data['class']=$class = $this->gurukul_model->getCourse();
        $class_array = array();
        $css = 'id="class_id" class="form-control property_type " style="width: 40%;" onChange="some_function();"';
        foreach ($class as $cat) {
            $class_array[$cat['class_id']] = $cat['name'];
        }
        $data['class_dropdown'] = form_dropdown('class_id', $class_array, $class_id, $css);
        
        $data['fee'] = $this->gurukul_model->getCourse($class_id);
        //print_r($data['fee']);
        $this->load->view('updateFee', $data);
    }

    /*
     * Collect student fee
     */
    public function collectFee() {
        $data['success'] = $this->input->get('success');
        //DS01012018001
        $this->load->library('form_validation'); //loading this library for form validation
        $data['student_code'] =  $student_code = $this->input->get_post('student_code');
        
        $data['studentDetails'] = $this->gurukul_model->getStudentDetails($student_code);
        //print_r($data['studentDetails']);
        $totalFeeDue = $this->gurukul_model->totalFeeDue($student_code);
        $data['feeStructure'] = $feeStructure = $this->gurukul_model->feeStructure($student_code);
        
        $years = array_keys($feeStructure);
        
        $total = 0;
        $i=0;
        if($totalFeeDue){
            foreach($totalFeeDue as $tf){
                //if(in_array($tf['year'],$years)){
                    $total = $total + $feeStructure[$tf['year']];
                    $totalFeeDue[$i]['amount_paid'] = $feeStructure[$tf['year']];
                //}
                    $i++;
            }
        }
        
        $data['totalFeeDue'] =$totalFeeDue;
        $data['total_due']=$total;
    
        //submit fee
        if($this->input->post()){
            $other_fee_type = $this->input->post('other_fee_type');
            $other_fee_amount = $this->input->post('other_fee_amount');
            
            if($other_fee_type)
                $this->form_validation->set_rules('other_fee_amount', 'Other Fee Amount', 'required');
            
            if($other_fee_amount)
                $this->form_validation->set_rules('other_fee_type', 'Other Fee Type', 'required');
            
            $this->form_validation->set_rules('course_fee', 'Payment Amount', 'required|greater_than[0]');
            
            if ($this->form_validation->run() == TRUE) {
                $course_fee = $total_due =  $this->input->post('course_fee');
                foreach ($totalFeeDue as $tF){
                    //if($course_fee>=$tF['amount_paid']){
                    $result = $this->gurukul_model->saveStudentFee($tF['month_fee_paid_for'],$tF['year'],$tF['amount_paid'],$student_code);
                    $course_fee = $course_fee - $tF['amount_paid'];
				}
				
				if($result){
				    $result = $this->gurukul_model->submitStudentOtherFee('Monthly Fee Amount',$total_due,$student_code);
				    $result = $this->gurukul_model->submitStudentOtherFee($other_fee_type,$other_fee_amount,$student_code);
				}
				
				redirect(base_url() . "index.php/fee/generatePaymentReport?student_code=".$student_code."&success=" . 1, 'location');
            }
        }
        
        $this->load->view('collectFee', $data);
    }
    
    /*
     * Reciept acknowledgement
     */
    
    public function generatePaymentReport(){

        $data['student_code'] =  $student_code = $this->input->get_post('student_code');
        $date=date('Y-m-d');
        $data['studentDetails'] = $this->gurukul_model->getStudentDetails($student_code);
        $data['payment_details'] = $this->gurukul_model->getpaiedStudentDetails($student_code,$date);
        $this->load->view('feeReciept', $data);
    }
    
    /*
     * print report
     */
    public function generatePrint(){
        $data['student_code'] =  $student_code = $this->input->get_post('student_code');
        $date=date('Y-m-d');
        $data['studentDetails'] = $this->gurukul_model->getStudentDetails($student_code);
        $data['payment_details'] = $this->gurukul_model->getpaiedStudentDetails($student_code,$date);
        
        $this->load->view('printReciept', $data);
    }
    // for generate pdf
    
    
    
    public function save_pdf(){
            //load mPDF library
            $this->load->library('m_pdf');
            //now pass the data//
            $data['mobiledata'] = $this->pdf->mobileList();
            $html=$this->load->view('pdf',$data, true); //load the pdf.php by passing our data and get all data in $html varriable.
            $pdfFilePath ="webpreparations-".time().".pdf";
            //actually, you can pass mPDF parameter on this load() function
            $pdf = $this->m_pdf->load();
            //generate the PDF!
            $stylesheet = '<style>'.file_get_contents('assets/css/bootstrap.min.css').'</style>';
            // apply external css
            $pdf->WriteHTML($stylesheet,1);
            $pdf->WriteHTML($html,2);
            //offer it to user via browser download! (The PDF won't be saved on your server HDD)
            $pdf->Output($pdfFilePath, "D");
            exit;
        }
    
    /*
     * function to delete courses
     */

    public function deleteCourse() {
        $data['course_id'] = $this->input->get_post("course_id");
        $this->course_model->deleteCourse($data);
        $this->load->view('listCourses');
    }

    public function listActivity() {
        $data['activityList'] = $this->course_model->getCourseActivities();
        $this->load->view('listCourseActivities', $data);
    }

    public function updateCourseActivities() {

        $data = array();
        $this->load->library('form_validation');

        $data['action'] = $action = $this->input->get_post('action');
        $data['activity_id'] = $activity_id = $this->input->get_post("activity_id");
        $data['course_id'] = $course_id = $this->input->get_post("course_id");
        $condition = array('activity_id' => $activity_id);
        $data['courseDetails'] = $courseDetails = $this->course_model->getCourseActivities($condition);

        //creating category dropdown
        $categories = $this->course_model->getCategories();
        $categories_array = array();
        $css = 'id="category_id" class="form-control property_type" onChange="some_function();"';

        foreach ($categories as $cat) {
            $categories_array[$cat['category_id']] = $cat['category_name'];
        }

        $selected_value = (isset($courseDetails[0]['category_id'])) ? $courseDetails[0]['category_id'] : '';
        $data['category_dropdown'] = form_dropdown('category_id', $categories_array, $selected_value, $css);

        //creating courses dropdown
        $courses = $this->course_model->getCourse();
        $courses_array = array();
        $css = 'id="course_id" class="form-control property_type" onChange="some_function();"';

        foreach ($courses as $cour) {
            $courses_array[$cour['course_id']] = $cour['course_name'];
        }

        $selected_value = (isset($courseDetails[0]['course_id'])) ? $courseDetails[0]['course_id'] : '';
        $data['course_dropdown'] = form_dropdown('course_id', $courses_array, $selected_value, $css);

        //creating activity type dropdown
        $activity_array = array('education' => 'Education', 'validation' => 'Validation');
        $css = 'id="type" class="form-control property_type"';
        $selected_type = (isset($courseDetails[0]['type'])) ? $courseDetails[0]['type'] : '';
        $data['type_dropdown'] = form_dropdown('type', $activity_array, $selected_type, $css);


        $this->form_validation->set_rules('activity_name', 'Activity Name', 'required');
        $this->form_validation->set_rules('type', 'Activity Type', 'required');
        $this->form_validation->set_rules('category_id', 'Category', 'required');
        $this->form_validation->set_rules('course_id', 'Course', 'required');
        $this->form_validation->set_rules('details', 'Json Details', 'required');

        if ($this->form_validation->run() == TRUE) {
            $data_insert['activity_name'] = $this->input->post("activity_name");
            $data_insert['type'] = $this->input->post("type");
            $data_insert['category_id'] = $this->input->post("category_id");
            $data_insert['course_id'] = $this->input->post("course_id");
            $data_insert['details'] = $this->input->post("details");
            $data_insert['activity_status'] = $this->input->post("button");

            //$data_insert['course_id'] = $course_id;

            if ($action == 'add') {
                $data_insert['activity_id'] = 'ca' . rand(10000, 99999);
                $result = $this->course_model->addCourseActivities($data_insert);
            } else {
                $result = $this->course_model->updateCourseActivities($data_insert, $activity_id);
            }


            if ($result)
                $success = 'success';
            else
                $success = 'error';

            redirect(base_url() . "index.php/course/listActivity?course_id=" . $course_id . "&success=" . $success, 'location');
        }
        $this->load->view('Add_activity', $data);
    }

    public function deleteCourseActivities() {

        $data['task_id'] = $this->input->get_post("course_id");
        $this->course_model->deleteCourseActivities($data);
        $this->load->view('listCourseActivities');
    }

    public function listCategory() {
        $this->session->flashdata('success_msg');
        $data = array();
        $data['success'] = $this->input->get('success');
        $data['categoryDetails'] = $this->course_model->getCategories();

        //print_r($data['categoryDetails']);
        $this->load->view('listCategory', $data);
    }

    /*
     * Function for addting/edit category 
     */

    public function updateCategory() {
        $data = array();
        $this->load->library('form_validation');
        $data_insert['category_id'] = $category_id = $this->input->get_post('category_id');
        $data['action'] = $action = $this->input->get_post("action");
        if ($action == 'add') {
            $getCategories = $this->course_model->getCategories($category_id);
        }

        $this->form_validation->set_rules('category_name', 'Category Name', 'required');

        if ($this->form_validation->run() == TRUE) {
            $data_insert['category_name'] = $this->input->get_post("category_name");
            if ($action === 'add') {
                //$categories_count = $this->course_model->countRows('categories');
                //$categories_count = ($categories_count == true) ? $categories_count + 1 : 1;
                $data_insert['category_id'] = 'cat' . str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
                $result = $this->course_model->addCategory($data_insert);
            } else {
                $result = $this->course_model->updateCategory($data_insert);
            }

            if ($result) {
                //$this->session->set_flashdata('success_msg', 'Your data updated successfully!');
                $update = 'success';
            } else {
                $update = 'error';
                //$this->session->set_flashdata('error_msg', 'Proble, updating your data successfully. Please try after sometime.');
            }
            redirect(base_url() . "index.php/course/listCategory?success=" . $update, 'location');
        }
        $this->load->view('updateCategory', $data);
    }

    public function listTask() {
        $user_id = $this->input->get_post('user_id');
        $this->load->model('task_model');
        $data = array();
        $data['tasks'] = $this->task_model->getTasks($user_id);
        $this->load->view('listTask', $data);
    }

    public function taskHistoryUpdates() {
        $this->load->model('task_model');
        $data['task_id'] = $task_id = $this->input->get_post('task_id');
        $data['history'] = $this->task_model->getTasks_History($task_id);
        $data['history_status'] = $this->task_model->getTasksDetailsByid($task_id);

        $data['photo_activity'] = false;
        $activityDetails = json_decode(@$data['history_status'][0]['details'], TRUE);

        if ($activityDetails && isset($activityDetails['activity_type'])) {

            $photoActivities = array('ARPhotoTraining_validation', 'RealShelfPhotoTraining_validation');
            if (in_array($activityDetails['activity_type'], $photoActivities)) {
                $data['photo_activity'] = TRUE;
            }
        }

        $this->load->view('taskHistoryUpdates', $data);
    }

    /*
     * Function to approve task
     */

    public function approveTask() {
        $this->load->model('task_model');
        $task_id = $this->input->get_post('task_id');
        $status = $this->input->get_post('status');
        if ($status == 'approve') {
            $data['task_status'] = 'completed';
            //$taskHistory= $this->task_model->updateTaskHistory($data,$task_id);
            //$update_id = $this->task_model->taskCount() + 1;
            $dataHidtory['update_id'] = str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
            $dataHidtory['task_id'] = $task_id;
            $dataHidtory['update_type'] = 'status';
            $dataHidtory['updated_date'] = date("Y-m-d H:i:s"); //use 24-hr format
            $tasks = $this->task_model->getTasksDetailsByid($task_id);
            $content = array("assignee" => $tasks[0]['user_name'], "current_status" => 'completed', "previous_status" => @$tasks[0]['task_status']);
            $dataHidtory['content'] = json_encode($content);
            $tasks = $this->task_model->taskHistoryUpdate($dataHidtory);
            $result = $this->task_model->updateTask($data, $task_id);

            if ($result)
                echo $success = 'success';
            else
                echo $success = 'error';
        } else
            echo 'error';
    }

    /*
     * Function to close task
     */

    public function cancelTask() {
        $this->load->model('task_model');
        $task_id = $this->input->get_post('task_id');
        $status = $this->input->get_post('status');
        if ($status == 'close') {
            $data['task_status'] = 'cancelled';
            //$update_id = $this->task_model->taskCount() + 1;
            $dataHidtory['update_id'] = str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
            $dataHidtory['task_id'] = $task_id;
            $dataHidtory['update_type'] = 'status';
            $dataHidtory['updated_date'] = date("Y-m-d H:i:s"); //use 24-hr format
            $tasks = $this->task_model->getTasksDetailsByid($task_id);
            $content = array("assignee" => $tasks[0]['user_name'], "current_status" => 'cancelled', "previous_status" => @$tasks[0]['task_status']);
            $dataHidtory['content'] = json_encode($content);
            $tasks = $this->task_model->taskHistoryUpdate($dataHidtory);
            $result = $this->task_model->updateTask($data, $task_id);

            if ($result)
                echo $success = 'success';
            else
                echo $success = 'error';
        } else
            echo 'error';
    }

    /*
     * Function to close task
     */

    public function reassignTask() {
        $this->load->model('task_model');
        $task_id = $this->input->get_post('task_id');
        $end_date = $this->input->get_post('end_date');

        $dataHidtory['update_id'] = str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
        $dataHidtory['task_id'] = $task_id;
        $dataHidtory['update_type'] = 'status';
        $dataHidtory['updated_date'] = date("Y-m-d H:i:s"); //use 24-hr format
        $tasks = $this->task_model->getTasksDetailsByid($task_id);
        $content = array("assignee" => $tasks[0]['user_name'], "current_status" => 'assigned', "previous_status" => @$tasks[0]['task_status']);
        $dataHidtory['content'] = json_encode($content);

        $tasks = $this->task_model->taskHistoryUpdate($dataHidtory);
        $data['task_status'] = 'assigned';
        $data['end_date'] = $end_date;
        $result = $this->task_model->updateTask($data, $task_id);

        if ($result)
            echo 'Task re-assignment is done!';
        else
            echo 'An error occured while re-assigning the task!';
    }

    public function getCourseAjax($id = 0) {
        $this->load->model('course_model');
        $data['courseDetails'] = $this->course_model->getCourse();
        die(json_encode($data['courseDetails']));
    }

    public function assignTask() {
        $this->load->model('user');
        $data['users'] = $this->user->getRows();
        $this->load->view('Assign_task', $data);
    }

    /*
     * 
     */

    public function addMessage() {
        $message = $this->input->get_post('message');
        $task_id = $this->input->get_post('task_id');
        $user_name = $this->input->get_post('user_name');

        $this->load->model('task_model');
        $dataHidtory['update_id'] = str_replace(array('.', ' '), array('', ''), uniqid('', true) . microtime(true));
        $dataHidtory['task_id'] = $task_id;
        $dataHidtory['update_type'] = 'message';
        $dataHidtory['updated_date'] = date("Y-m-d H:i:s"); //use 24-hr format
        //$tasks= $this->task_model->getTasksDetailsByid($task_id);
        //$content= array("assignee"=>$tasks[0]['user_name'],"current_status"=>'assigned',"previous_status"=>@$tasks[0]['task_status']);
        $content = array("sender" => $user_name, "message" => $message); //	{"sender": "test3", "message": "3"}
        $dataHidtory['content'] = json_encode($content);
        $tasks = $this->task_model->taskHistoryUpdate($dataHidtory);
        if ($tasks == true) {
            echo 'Messaged successfully!';
        } else {
            echo 'Message failed!';
        }
    }

}

?>
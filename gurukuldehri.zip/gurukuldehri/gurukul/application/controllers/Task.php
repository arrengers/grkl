<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('task_model'); //course_api_model
    }

    /*
     * Function to list task available
     */

    public function index() {

        if (isset($_GET['page']) & !empty($_GET['page'])) {
            $data['curpage'] = $curpage = $_GET['page'];
        } else {
            $data['curpage'] = $curpage = 1;
        }

        $perpage = 10;
        $pagination['start'] = ($curpage * $perpage) - $perpage;
        $pagination['end'] = '10';

        $filters = array();

        if (isset($_GET["activity_type"])) {
            $filters[] = "activity_type='{$_GET["activity_type"]}'";
        }
        if (isset($_GET["activity_id"])) {
            $filters[] = "activity_id='{$_GET["activity_id"]}'";
        }
        if (isset($_GET["task_status"])) {
            $filters[] = "task_status='{$_GET["task_status"]}'";
        }
        if (isset($_GET["created_by"])) {
            $filters[] = "created_by='{$_GET["created_by"]}'";
        }

        $pagination["filters"] = $filters;

        $taskActivities = $this->task_model->getTaskActivities();
        $createdByList = array();

        if ($this->session->get_userdata() && isset($this->session->get_userdata()['role'])) {
            if ($this->session->get_userdata()['role'] == "admin") {
                $createdByList = $this->task_model->getTaskCreatedBy();
            }
        }

        $totalres = intval($this->task_model->getTasksCount($pagination));

        $data['endpage'] = ceil($totalres / $perpage);
        $data['startpage'] = 1;
        $data['nextpage'] = $curpage + 1;
        $data['previouspage'] = $curpage - 1;
        $data['taskactivities'] = $taskActivities;
        $data['createdByList'] = $createdByList;

        $data['tasks'] = $this->task_model->getTasks(null, $pagination);
        $this->load->view('listTask', $data);
    }

    public function addTask() {

        $this->load->library('form_validation');

        $this->form_validation->set_rules('taskname', 'Task Name', 'required');
        if ($this->form_validation->run() == TRUE) {
            $data['taskname'] = $this->input->post("taskname");
            if ($action == 'Add') {
                $data['status'] = $this->task_model->addTask();
            } else {
                $data['status'] = $this->task_model->updateTask();
            }
        }

        $this->load->view('addTask', $data);
    }

    public function getUserTasks() {
        $user_id = $this->input->get('user_id', TRUE);
        $this->load->model('task_model');
        $tasks = $this->task_model->getTasksByUser($user_id);

        echo json_encode($tasks, TRUE);
    }

    public function assignTask() {
        $this->load->model('user');
        $this->load->model('course_model');

        $data['users'] = $this->user->getRows();

        if ($this->session->get_userdata() && isset($this->session->get_userdata()['user_id'])) {
            $data['current_user'] = $this->session->get_userdata()['user_id'];
        }

        $data['activities'] = $this->course_model->getCourseActivities();
        $this->load->view('assignTask', $data);
    }

    public function assignGroupTask() {
        $this->load->model('user');
        $this->load->model('course_model');

        if ($this->session->get_userdata() && isset($this->session->get_userdata()['user_id'])) {
            $data['current_user'] = $this->session->get_userdata()['user_id'];
        }
        
        //creating Assignment Type dropdown
        $assignment_type_array= array('group'=>'Group','user'=>'User');
        $css = 'id="assignment_type" class="form-control property_type"';
        $selected_value = $this->input->post('assignment_type');
        $data['assginment_type_dropdown'] = form_dropdown('assignment_type', $assignment_type_array, $selected_value, $css);
        
        //creating User dropdown
        $users = $this->user->getRows();
        $users_array= array(''=>'----');
        $css = 'id="select_user" class="form-control property_type"';
        foreach ($users as $usr) {
        	$users_array[$usr['user_id']] = $usr['user_id'].' | '.$usr['user_name'];
        }
        $selected_value = $this->input->post('select_user');
        $data['user_dropdown'] = form_dropdown('select_user', $users_array, $selected_value, $css);
        
        $data['activities'] = $this->course_model->getCourseActivities();
        
        //creating Group dropdown
        $group = $this->user->getGroups();
        $group_array= array(''=>'----');
        $css = 'id="select_group" class="form-control property_type"';
        foreach ($group as $grp) {
        	$group_array[$grp['group_id']] = $grp['group_name'];
        }
        $selected_value = (isset($courseDetails[0]['select_group'])) ? $courseDetails[0]['select_group'] : '';
        $data['group_dropdown'] = form_dropdown('select_group', $group_array, $selected_value, $css);
        
        $package= $this->user->getPackage();
        $package_array= $package_data = array();
        $css = 'id="package" class="form-control property_type"';
        foreach ($package as $key=>$pckg) {
        	if(!is_array($pckg)){
        		$package_data[$key]=$pckg;
        	}
        }
        $package_array['----']='----';
        $package_array[$package_data['package']] = $package_data['name'];
        $selected_value = $this->input->post('package');
        $data['package_dropdown'] = form_dropdown('package', $package_array, $selected_value, $css);
        
        $this->load->view('assignGroupTask', $data);
    }

    public function deleteTask() {
        $data['task_id'] = $this->input->get_post("task_id");
        $this->task_model->deleteTask($data);
        $this->load->view('listTasks', $data);
    }

    public function assignTask_post() {
        $json_data = file_get_contents('php://input');
        $taskAssignData = json_decode($json_data, true);

        $insert = $this->task_model->taskAssignInsert($taskAssignData);

        if ($insert) {
            echo "Task added successfully";
        } else {
            echo "Error in adding task";
        }
    }

    public function assignGroupTaskToUserGroup() {
    	$json_data = file_get_contents('php://input');
    	$taskAssignData = json_decode($json_data, true);
    	$this->load->model('user'); //course_api_model
    	$insert=null;
    	
    	$insertData = $taskAssignData;
    	$insertData['parent_task_id']= '';

    	//Assigning task to users of a group
    	if($taskAssignData['assignment_type']=='group'){
    		$group= $this->user->getGroupsUser($taskAssignData['select_group']); //getting all user from particular group
    		if(is_array($group)){
    			foreach ($group as $grp){
                    $insertData['user_id']=$grp['user_id'];
                    
                    if($taskAssignData['package']!='----'){ //Assigning package to users of a group
                        $package= $this->user->getPackage();
                        foreach ($package['activites'] AS $activites){
                    	    $insertData['activity_id'] =  $activites['id'];
                    	    $insertData['parent_task_id'] =  ($activites['parent']==null)?'':$activites['parent'];
      	                    $insert = $this->task_model->taskAssignInsert($insertData);
			            }
			            
			        }else{ //Assigning package to users of a group
			            $insert = $this->task_model->taskAssignInsert($insertData);
			        }
                }
    	    }
    	}else if($taskAssignData['assignment_type']=='user'){
            if($taskAssignData['package']!='----'){ //Assigning package to users of a group
            	$package= $this->user->getPackage();
                foreach ($package['activites'] AS $activites){
                    $insertData['activity_id'] =  $activites['id'];
                    $insertData['parent_task_id'] =  ($activites['parent']==null)?'':$activites['parent'];
                    $insert = $this->task_model->taskAssignInsert($insertData);
    			}
            }else{ //Assigning package to users of a group
            	$insert = $this->task_model->taskAssignInsert($insertData);
    		}
    	}
    	
    	if ($insert) {
    		echo "Task added successfully";
    	} else {
    		echo "Error in adding task";
    	}
    }
    
}

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class Task_api extends REST_Controller{
	var $error_array=array();
	public function __construct(){
		parent::__construct();
		$this->load->model('task_model');		
		$this->load->model('user');
		$this->error_array=array(205=>'Unauthorized token',206=>'Your session has been expired');
	}
	
	/*
	 * Function to Task details
	 */
	public function task_get($id = 0) {
		$token=$this->user->auth();
		
		if(is_object($token)){
			$course= $this->task_model->getTasks($token->users_id);
			if(!empty($course)){
				$this->response([
						'status' => 'SUCCESS',
                                                'error' =>['error_code' => 0, 'error_message' => ''],
						'data' =>['tasks'=>$course]
				], REST_Controller::HTTP_OK);
			}else{
				$this->response([
						'status' => 'ERROR',
						'error' =>['error_code' => 600,
								'error_message' => 'No task found'],
                                                'data'=> json_decode("{}")
				], REST_Controller::HTTP_OK);
			}
		}else {
			$this->response(array('error'=>['error_code'=>$token,'error_messge'=>$this->error_array[$token]]), REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	/*
	 * Fucntion to upload FILE through post method API
	 */	
	public function fileUpload_post(){
		ini_set('upload_max_filesize', '2000');
		ini_set('post_max_size', '2500');
		ini_set('memory_limit', '3000');
		
		$token=$this->user->auth();
		$fileType = true;
		if (isset($_SERVER['HTTP_USER_AGENT']) && ((stripos($_SERVER['HTTP_USER_AGENT'], "Mobi") !== false) || (stripos($_SERVER['HTTP_USER_AGENT'], "Mobile")!==false))) {
			$fileType = $this->input->post('file_type', TRUE);
		}
		if(isset($_FILES["file_content"]["name"]) && $_FILES["file_content"]["name"]!='' && $fileType == true){
			if(is_object($token)){
				// generate random name
				$dataInsert['file_extention'] = pathinfo($_FILES["file_content"]["name"], PATHINFO_EXTENSION);
				$dataInsert['file_id'] = $file_id = str_replace(array('.',' '), array('',''), uniqid('',true).microtime(true));
				$dataInsert['file_title']=$_FILES["file_content"]["name"];
				$dataInsert['file_type']=(is_string($fileType))?$fileType:$_FILES["file_content"]["type"];
				$upload_path= $this->config->item('upload_path');
				$file_title=str_replace(array('-',' ','(',')'),array(''),$_FILES["file_content"]["name"]);
				//$newname = $upload_path. $file_title;
				$newname = $upload_path. $file_id.'.'.$dataInsert['file_extention'];
				$dataInsert['file_description']=$this->input->post('file_description', TRUE);
				if ((file_exists($upload_path)) || (is_dir($upload_path))) {
					//chmod($upload_path,0777);
					if(!is_dir($upload_path)){
						$this->response([
								'status' => 'ERROR',
								'error' =>['error_code' => 600,
										'error_message' => 'File upload path is not correct!'],
								'data'=>[]
						], REST_Controller::HTTP_NOT_FOUND);
					}
				}else {
					mkdir($upload_path, 0777);
				}
				
				
				if(move_uploaded_file($_FILES["file_content"]["tmp_name"], $newname)){
					$this->task_model->addFile($dataInsert);
					$this->response([
							'status' => 'SUCCESS',
                                                'error' =>['error_code' => 0, 'error_message' => ''],'data' =>['file_id'=>$dataInsert['file_id']]
					], REST_Controller::HTTP_OK);
				} else{
					$this->response([
							'status' => 'ERROR',
							'error' =>['error_code' => 600,
									'error_message' => 'Sorry, there was an error uploading your file!'],
							'data'=>[]
					], REST_Controller::HTTP_NOT_FOUND);
				}
			}else {
				$this->response(array('error'=>['error_code'=>$token,'error_messge'=>$this->error_array[$token]]), REST_Controller::HTTP_BAD_REQUEST);
			}
		}else{
			$this->response([
					'status' => 'ERROR',
					'error' =>['error_code' => 600,
							'error_message' => 'Proper input need to be provided!'],
					'data'=>[]
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}
}




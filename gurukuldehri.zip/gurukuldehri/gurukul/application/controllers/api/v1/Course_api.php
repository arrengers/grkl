<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class Course_api extends REST_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('course_model');
	}
	
	
	/*
	 * Function to course details
	 */
	public function course_get($id = 0) {
		//returns all rows if the id parameter doesn't exist,
		//otherwise single row will be returned
		$course= $this->course_model->getCourse($id);
		
		//check if the user data exists
		if(!empty($course)){
			//set the response and exit
			$this->response($course, REST_Controller::HTTP_OK);
		}else{
			//set the response and exit
			$this->response([
					'status' => FALSE,
					'message' => 'No user were found.'
			], REST_Controller::HTTP_NOT_FOUND);
		}
	}
	
}

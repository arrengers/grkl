<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class Task_history_api extends REST_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('task_model');
        $this->load->model('user');
        $this->error_array = array(205 => 'Unauthorized token', 206 => 'Your session has been expired');
    }

    /*
     * Function to Task history
     */

    public function taskHistory_get($id = 0) {

        if (!is_string($id) && ($id == 0)) {
            $this->response([
                'status' => 'ERROR',
                'error' => ['error_code' => 600,
                    'error_message' => 'Task Id missing!'],
                'data' => []
                    ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
            $token = $this->user->auth();
            if (is_object($token)) {
                $tasks_history = $this->task_model->getTasksHistory($id, $token);

                if (isset($tasks_history["error"])) {

                    $this->response([
                        'status' => 'ERROR',
                        'error' => ['error_code' => 600,
                            'error_message' => $tasks_history["error"]],
                        'data' => []
                            ], REST_Controller::HTTP_NOT_FOUND);
                } else {

                    $this->response([
                        'status' => 'SUCCESS',
                        'error' =>['error_code' => 0, 'error_message' => ''],
                        'data' => ['task_update_history' => $tasks_history]
                            ], REST_Controller::HTTP_OK);
                }
            } else {
                $this->response(array('error' => ['error_code' => $token, 'error_messge' => $this->error_array[$token]]), REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function taskHistory_post($id = 0) {
        $json_data = file_get_contents('php://input');
        $json_data_decoded = json_decode($json_data);

        if (
                (isset($json_data_decoded->timestamp) && (!empty($json_data_decoded->timestamp))) &&
                (isset($json_data_decoded->type) && (!empty($json_data_decoded->type))) &&
                (isset($json_data_decoded->content)) && (!empty($json_data_decoded->content))) {
            $userData = array();
            $userData['task_id'] = $id;
            $userData['updated_date'] = $json_data_decoded->timestamp;
            $userData['update_type'] = $json_data_decoded->type;
            
            if($json_data_decoded->type=='file_attach'){
            	$ext = explode('.',$json_data_decoded->content->file_name);
            	$ext = end($ext);
            	$json_data_decoded->content->file_location=  $json_data_decoded->content->file_id.'.'.$ext;
            }

            $userData['content'] = json_encode($json_data_decoded->content);
            $token = $this->user->auth();
            
            if (is_object($token)) {

                if (!in_array($userData['update_type'], array('status','message','data_update','file_attach','chat','notification'))) {
                    $this->response([
                        'status' => 'ERROR',
                        'error' => ['error_code' => 600,
                            'error_message' => 'update_type is not valid'],
                        'data' => []
                            ], REST_Controller::HTTP_BAD_REQUEST);
                } else {
                    $userData['update_id'] = str_replace(array('.',' '), array('',''), uniqid('',true).microtime(true));
                    //insert user data
                    $result = $this->task_model->getTasksByid($id);
                    if ($result == false) {
                        $this->response([
                            'status' => 'ERROR',
                            'error' => ['error_code' => 600,
                                'error_message' => 'Task id is not valid!'],
                            'data' => []
                                ], REST_Controller::HTTP_BAD_REQUEST);
                    } else {
                        $insert = $this->task_model->taskHistoryUpdate($userData);
                        
                        //update status of the task in tasks table
                        $update = false;
                        if ($userData['update_type'] == "status") {
                            $data['task_status'] = json_decode($userData['content'])->current_status;
                            $update = $this->task_model->updateTask($data,$id);
                        }

                        //check if task history is updated & task status is updated
                        if ($insert && $update) {
                            //set the response and exit
                            $this->response([
                                'status' => 'SUCCESS',
                                'error' =>['error_code' => 0, 'error_message' => ''],
                                'data' => ['success_msg' => 'Task history & task status updated successfully!']
                                    ], REST_Controller::HTTP_OK);
                        }
                    }
                }
            } else {
                $this->response(array('error' => ['error_code' => $token, 'error_messge' => $this->error_array[$token]]), REST_Controller::HTTP_BAD_REQUEST);
            }
        } else {
            //set the response and exit
            $this->response([
                'status' => 'ERROR',
                'error' => ['error_code' => 600,
                    'error_message' => 'Proper input need to be provided!'],
                'data' => []
                    ], REST_Controller::HTTP_BAD_REQUEST);

            $this->response("Provide complete user information to create.", REST_Controller::HTTP_BAD_REQUEST);
        }
    }

}

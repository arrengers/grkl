
function getPropertyHtml() {

    var propertyHtml = "";
    propertyHtml += "<tr class='task-property'>";

    propertyHtml += "<td class=''>";
    propertyHtml += "<button class='btn btn-sm add-property control-buttons' onclick='addProperty(this)'>+</button>";
    propertyHtml += "</td>";

    propertyHtml += "<td class=''>";
    propertyHtml += " <button class='btn btn-sm remove-property control-buttons' onclick='removeProperty(this)'>-</button>";
    propertyHtml += "</td>";

    propertyHtml += "<td>";
    propertyHtml += "<div class='property-type-container'>";
    propertyHtml += "<select class='form-control property_type' name='property_type' onchange='updatePropertyType(this)'>";
    propertyHtml += "<option value='timer' selected='selected'>Timer</option>";
    propertyHtml += "<option value='url'>Url</option>";
    propertyHtml += "<option value='overlay'>Overlay</option>";
    propertyHtml += "<option value='array'>URL Array</option>";
    propertyHtml += "</select>";
    propertyHtml += "</div>";
    propertyHtml += "</td>";

    propertyHtml += "<td>";
    propertyHtml += "<table class='property-value-container'>";
    propertyHtml += "<tr><td>";
    propertyHtml += "<input type='text' class='form-control property_value' name='property_value' value='' placeholder='Property Value'>";
    propertyHtml += "</td></tr>";
    propertyHtml += "</table>";
    propertyHtml += "</td>";

    propertyHtml += "</tr>";

    return propertyHtml;
}

function getSimpleProperty() {

    var propertyHtml = "";

    propertyHtml += "<tr><td>";
    propertyHtml += "<input type='text' class='form-control property_value' name='property_value' value='' placeholder='Property Value'>";
    propertyHtml += "</td></tr>";

    return propertyHtml;
}

function addProperty(me) {
    $(me).parent().parent().parent().append(getPropertyHtml());
}

function removeProperty(me) {
    $(me).parent().parent().remove();
}

function updatePropertyType(me) {

    if (me.value === "overlay" || me.value === "array") {
        $(me).parent().parent().parent().find(".property-value-container").html(getPropertyHtml());
    } else {
        $(me).parent().parent().parent().find(".property-value-container").html(getSimpleProperty());
    }
}

$(document).ready(function () {
    var firstProperty = getPropertyHtml();
    $(".panel-builder").append(firstProperty);
});
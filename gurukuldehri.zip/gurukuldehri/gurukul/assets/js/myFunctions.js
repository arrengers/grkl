// Create cookie method
function setCookie(cname, cvalue, exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  var expires = "expires="+ d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

// Get cookie method
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


// Check Uncheck ALL CHECKBOX
function chkAllcheckbox(element){
   $('input:checkbox').not(element).prop('checked', element.checked);
}

// DELETE using checkbox DELETEALL
/*var Obj = {
      targetDivId    : "target-content",
      pageURL        : "api/user.php",                   // (Mainly use for delete functionality)
      paginationUrl  : "api/userAjax.php?page=",         // after delete pagination reset
      perPageRecord  : "<?php echo PER_PAGE_RECORD;?>",  // after delete pagination reset
      checkboxArrayName : "userid",
      searchBoxId    : "search"
}; */
function deleteCheckboxRecord(Obj){
  if ($('#'+Obj['targetDivId']+' :checkbox:checked').length > 0){
      // process request when atleast one of the checkbox is checked
      if (confirm("Do you really want to delete ?") == true){
          $.ajax(
            {
                url : Obj['pageURL'],
                type: "DELETE",
                data : $('[name="' + Obj['checkboxArrayName'] + '[]" ]').serialize(), // $('[name="userid[]"]').serialize();
                success: function(data) {
                    //jsonData = JSON.parse(data);
                    jsonData = data;
                    if(jsonData['status'] == "ERROR"){
                        $(".errorStatus").html('<div class="alert alert-danger"><strong>ERROR !</strong> &nbsp;'+ jsonData['msg'] + '</div>');
                    } else {
                        $('#'+ Obj['targetDivId'] +' input:checked').parent().parent().remove();
                        $(".errorStatus").html('<div class="alert alert-success"><strong>SUCCESS !</strong> &nbsp;'+ jsonData['msg'] + '</div>');
                        $(".errorStatus").delay(3000).slideUp(800);
                        // after delete recall pagination script
                        startPagination(Obj);

                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    $(".errorStatus").html('<div class="alert alert-warning"><strong>ERROR!</strong> '+ errorThrown + '</div>');
                }
            });
          } else {
            return false;
        }
  } else {
    // something else when not checked
    alert("Please select something to proceed");
    return false;
  }
}

// SEARCH using textbox keyUp EVENT
function searchDataAjax(element, Obj ) {
    var searchRequest = null;
    var minlength = 3;
    var that = element;
    value = $(element).val();

    if (value.length >= minlength ) {
        if (searchRequest != null)
            searchRequest.abort();
        startPagination(Obj);
    }

    if(value == "")
    startPagination(Obj);
}

// Pagination function 1
function startPagination(Obj) {
   pageUrl       = Obj['paginationUrl'];
   perPageRecord = Obj['perPageRecord'];              // display per page record
   searchBoxId   = Obj['searchBoxId'];                // search textbox id
   targetDivId   = Obj['targetDivId'];                // after ajax data would be rendered to div id
   extraParameter = Obj['extraParameter'];           // used for extraparameter bydefault put it 0
   alert('sssssssssss');
   $("#"+ targetDivId ).html('loading...');
   addUrl = ( $("#search").val() != "" ) ? "&search_keyword="+ $("#"+ searchBoxId ).val() : "";
   addUrl = addUrl.concat( (extraParameter != 0) ? "&"+ extraParameter : "" );

   $("#"+ targetDivId ).load(pageUrl+1 + addUrl, function(responseTxt, statusTxt, xhr){

      if(statusTxt == "success"){
        var total_records =  $("#"+ targetDivId ).find("#total_records").val();
        createPagination(total_records, perPageRecord, pageUrl, searchBoxId, extraParameter);
      } else {
          $("#target-content").html('There might be some problem ...');
      }
   });
}
// Pagination function 2
function createPagination(total_records, perPageRecord, pageUrl, searchBoxId, extraParameter){
    $("#paginationLink").pagination({
        items: total_records,
        itemsOnPage: perPageRecord,
        cssStyle: 'light-theme',
        onPageClick : function(pageNumber,event) {
            event.preventDefault();
            $("#target-content").html('loading...');
            addUrl = ( $('#'+ searchBoxId ).val() != "" ) ? "&search_keyword="+ $('#'+ searchBoxId ).val() : "";
            addUrl = addUrl.concat( (extraParameter != 0) ? "&"+ extraParameter : "" );
            $("#target-content").load(pageUrl + pageNumber + addUrl );
            $("#paginationLink").pagination('redraw');
        }
     });
 }



//**************************************************************
//*************** Highchart function ****************************
function createPieChart(pieObj){
    // Build the chart
    Highcharts.chart(pieObj['containerId'], {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: pieObj['chartTitle']
        },
        credits: {
                    enabled: false      // use to hide highchart.com link from chart
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
          //pointFormat: '{series.name}: <b>{point.y:0f} people</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: false
                },
                showInLegend: true
            }
        },
        series: [{
            name: pieObj['stepName'],
            colorByPoint: true,
            data : pieObj['seriesData']
        }]
      });
  }

// Line chart
  function createLineChart(lineObj){
      Highcharts.chart(lineObj['containerId'], {

      title: {
          text: lineObj['chartTitle']
      },

      subtitle: {
          //text: 'Source: thesolarfoundation.com'
      },
      xAxis: {
          title: {
              text: lineObj['xAxisTitle']
          },
          categories: lineObj['xAxisData']  // set x-axis data  here
      },
      yAxis: {
          min: 0,
          allowDecimals: false,   // used to remove default float value (use integer only) from y axis
          title: {
              text: lineObj['yAxisTitle']
          }
      },
      legend: {
          layout: 'vertical',
          align: 'right',
          verticalAlign: 'middle'
      },
      credits: {
                  enabled: false      // use to hide highchart.com link from chart
      },
      /*plotOptions: {
          series: {
              pointStart: 2010
          }
      },*/

      series: [{
          name: lineObj['seriesName'],
          data: lineObj['seriesData']
      }]

    });
  }

  function createColumnChart(columnObj){
    Highcharts.chart(columnObj['containerId'], {
        chart: {
            type: 'column'
        },
        title: {
            text: columnObj['chartTitle']
        },
        subtitle: {
            text: 'Source: <a href="http://en.wikipedia.org/wiki/List_of_cities_proper_by_population">Wikipedia</a>'
        },
        xAxis: {
            type: 'category',
            labels: {
                rotation: -45,
                style: {
                    fontSize: '13px',
                    fontFamily: 'Verdana, sans-serif'
                }
            }
        },
        yAxis: {
            min: 0,
            title: {
                text:  columnObj['yAxisTitle']
            }
        },
        legend: {
            enabled: false
        },
        tooltip: {
            pointFormat: 'Population in 2008: <b>{point.y:.1f} millions</b>'
        },
        series: [{
            name: columnObj['seriesName'],
            data: columnObj['seriesData']

        }]
    });
  }


$(document).ready(function () {

    // DATEPICKER
    $("#start_date, #end_date").daterangepicker({
        'singleDatePicker': true,
        'showDropdowns': true,
        'locale': {
            'format': 'YYYY-MM-DD'
        },
    });

    $("#end_date").val(getFutureDate(10));
});
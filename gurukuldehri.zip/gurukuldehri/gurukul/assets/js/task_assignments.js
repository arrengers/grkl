
$(document).ready(function () {
    updateUserTasks();

    // DATEPICKER
    $("#start_date, #end_date").daterangepicker({
        'singleDatePicker': true,
        'showDropdowns': true,
        'locale': {
            'format': 'YYYY-MM-DD'
        },
    });

    $("#start_date").val(getCurrentDate());
    $("#end_date").val(getFutureDate(10));

    $("#select-user").prop("disabled", true);

    
    /*this block of code need to replaced with code from views/assignGroupTask.php*/
    $("#assignment-type").change(function () {
        var assignmentType = $(this).val();
        if (assignmentType === "user") {
            $("#selected_user").prop("disabled", false);
            $("#selected_group").prop("disabled", true);

        } else if (assignmentType === "group") {
            $("#selected_user").prop("disabled", true);
            $("#selected_group").prop("disabled", false);
        }
        //alert();
    });
});

function assignTask() {

    var selectedUser = $("#selected-user").val();
    var activityId = $("#activity").val();
    var parentTask = $("#user-task-list").val();

    var startDate = $("#start_date").val();
    var endDate = $("#end_date").val();
    var currentUser = $("#current_user").val();


    if (startDate.trim() === '' || endDate.trim() === '') {
        alert("Start Date and End date should not be empty");
    } else {

        var inputJson = {
            user_id: selectedUser,
            activity_id: activityId,
            parent_task_id: parentTask,
            start_date: startDate,
            current_user: currentUser,
            end_date: endDate
        };

        console.log(inputJson);

        $.ajax(
                {
                    url: "assignTask_post",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify(inputJson),
                    datatype: 'json',
                    success: function (data) {
                        alert(data);
                    },
                    error: function (jqXHR, textStatus, errorThrown)
                    {
                        alert("Error in adding new task");
                    }
                });
    }

}

function updateUserTasks() {

    var selectedUser = $('#selected-user').val();
    $("#user-task-list").html("");
    $("#user-task-list").append("<option value='' selected='selected'>---</option>");

    var task_name = "";

    $.getJSON("getUserTasks?user_id=" + selectedUser, function (data) {
        $.each(data, function (key, val) {
            console.log(val);

            var task_name = "[" + val.course_category + " | " + val.activity_type + "] - " + val.activity_name;
            $("#user-task-list").append("<option value='" + val.task_id + "'>" + task_name + "</option>");
        });
    });

}
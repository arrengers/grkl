	SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
	SET AUTOCOMMIT = 0;
	START TRANSACTION;
	SET time_zone = "+00:00";

	--
	-- Database: `arvr_training`
	--

	USE `arvr_training`;

	--
	-- Clean data from tables
	--

	DELETE FROM `categories`;
	DELETE FROM `courses`;
	DELETE FROM `course_activities`;
	DELETE FROM `tasks`;
	DELETE FROM `task_updates`;
	DELETE FROM `training_files`;
	DELETE FROM `users`;
	DELETE FROM `users_authentication`;

	--
	-- Insert data in to the table `categories`
	--

	INSERT INTO `categories` (`category_id`, `category_name`) VALUES
	('r1', 'Rainbow'),
	('e1', 'eCollection'),
	('l1', 'LHHT');

	--
	-- Insert data in to the table `courses`
	--

	INSERT INTO `courses` (`course_id`, `course_name`) VALUES
	('ec1', 'eCollection Photo Training'),
	('ec2', 'eCollection 360 Video Training'),
	('ec3', 'eCollection Store Game Training');

	--
	-- Insert data in to the table `course_activities`
	--

	INSERT INTO `course_activities` (`activity_id`, `activity_name`, `type`, `course_id`, `category_id`, `activity_status`, `details`) VALUES
	('ca1', 'eCollection AR Photo Training', 'education', 'ec1', 'e1', 'active', '{\"activity_type\": \"ARPhotoTraining_education\", \"activity_details\": {\"description\": {\"text\": \"Try to align shelf\"}}}'),
	('ca2', 'eCollection AR Photo Training', 'validation', 'ec1', 'e1', 'active', '{\"activity_type\": \"ARPhotoTraining_validation\", \"activity_details\": {\"timeout\": 120, \"description\": {\"text\": \"Try to align shelf\"}, \"sample_rate\": 20}}'),
	('ca3', 'eCollection Real Shelf Photo Training', 'validation', 'ec1', 'e1', 'active', '{\"activity_type\": \"RealShelfPhotoTraining_validation\", \"activity_details\": {\"timeout\": 120, \"description\": {\"text\": \"Try to align shelf\"}, \"sample_rate\": 20}}');


	--
	-- Insert data in to the table `tasks`
	--

	SET @startdate = UTC_DATE();
	SET @enddate = DATE_ADD(@startdate, INTERVAL 30 DAY);
	SET @utctimestamp = UTC_TIMESTAMP();

	INSERT INTO `tasks` (`task_id`, `user_id`, `activity_id`, `start_date`, `end_date`, `parent_task_id`, `task_status`, `assignment_date`, `updated_date`) VALUES
	('t1', 'avinash55', 'ca1', @startdate, @enddate, '', 'assigned', @utctimestamp, @utctimestamp),
	('t2', 'avinash55', 'ca2', @startdate, @enddate, 't1', 'assigned', @utctimestamp, @utctimestamp),
	('t3', 'avinash55', 'ca3', @startdate, @enddate, 't2', 'assigned', @utctimestamp, @utctimestamp),
	('t6', 'test1', 'ca1', @startdate, @enddate, '', 'assigned', @utctimestamp, @utctimestamp),
	('t7', 'test1', 'ca2', @startdate, @enddate, 't6', 'assigned', @utctimestamp, @utctimestamp),
	('t8', 'test1', 'ca3', @startdate, @enddate, 't7', 'assigned', @utctimestamp, @utctimestamp),
	('t10', 'test2', 'ca1', @startdate, @enddate, '', 'assigned', @utctimestamp, @utctimestamp),
	('t11', 'test2', 'ca2', @startdate, @enddate, 't10', 'assigned', @utctimestamp, @utctimestamp),
	('t12', 'test2', 'ca3', @startdate, @enddate, 't11', 'assigned', @utctimestamp, @utctimestamp);


	--
	-- Insert data in to the table `users`
	--

	INSERT INTO `users` (`user_id`, `user_name`, `password`, `last_login`) VALUES
	('test1', 'User Test1', '889dc9d921927c09b1a72b78442288dd94716a587993dbee2fe8f1ac52980147', @utctimestamp),
	('test2', 'User Test2', '889dc9d921927c09b1a72b78442288dd94716a587993dbee2fe8f1ac52980147', @utctimestamp),
	('test3', 'User Test3', '889dc9d921927c09b1a72b78442288dd94716a587993dbee2fe8f1ac52980147', @utctimestamp),
	('test4', 'User Test4', '889dc9d921927c09b1a72b78442288dd94716a587993dbee2fe8f1ac52980147', @utctimestamp),
	('test5', 'User Test5', '889dc9d921927c09b1a72b78442288dd94716a587993dbee2fe8f1ac52980147', @utctimestamp),
	('avinash55', 'Avinash Kumar', '889dc9d921927c09b1a72b78442288dd94716a587993dbee2fe8f1ac52980147', @utctimestamp),
	('vinod55', 'Vinod Kadam', '889dc9d921927c09b1a72b78442288dd94716a587993dbee2fe8f1ac52980147', @utctimestamp);

	--
	-- Insert data in to the table `users_authentication`
	--

	SET @utctimestamp30days = DATE_ADD(@utctimestamp, INTERVAL 30 DAY);
	
	INSERT INTO `users_authentication` (`id`, `users_id`, `token`, `expired_at`, `created_at`, `updated_at`) VALUES
	(1, 'test1', '7c6c4a2efa9493636a5c9f055d958891a3c8640481a32acb7364d41a3d81cb48', @utctimestamp30days, @utctimestamp, @utctimestamp),
	(2, 'test2', '475854ea96ff88129e0cc39637f49730b6f884f6d6764f4f2488ecb264ac07c5', @utctimestamp30days, @utctimestamp, @utctimestamp),
	(3, 'test3', '0fbef6a886d9b1006243d1a63943c69b2f99d9086a3b65c1390fa75b6f090045', @utctimestamp30days, @utctimestamp, @utctimestamp),
	(4, 'test4', 'b687255c47612e9fdc27428dc9d4b3fae8124cd47cfef3bf7d48f88fe261d308', @utctimestamp30days, @utctimestamp, @utctimestamp),
	(5, 'test5', 'cc343b969cc973c0d9b2d45aead13d3340c79760a1f761e4f21e1c5b635c9ce9', @utctimestamp30days, @utctimestamp, @utctimestamp),
	(6, 'avinash55', 'c85f5c31a48a7beb0577cdd6561d1fc972d942baf20fdbb1920f9a9be47f0119', @utctimestamp30days, @utctimestamp, @utctimestamp),
	(7, 'vinod55', 'ebca345ca7b0e59b67c7aeba554bc3fbc945090b0d1c31eaa54e95411b5d18f1', @utctimestamp30days, @utctimestamp, @utctimestamp);

	COMMIT;

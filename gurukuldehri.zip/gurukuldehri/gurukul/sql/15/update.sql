ALTER TABLE `users`
	ADD COLUMN `email` VARCHAR(100) NULL AFTER `user_name`;

ALTER TABLE `training_files`
ADD `external_file_id` varchar(100) NOT NULL;
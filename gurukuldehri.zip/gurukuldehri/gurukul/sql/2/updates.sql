CREATE VIEW task_lists as SELECT
t.activity_id, ca.activity_name, ca.`type` as `activity_type`,
cat.category_name as `course_category`, t.task_id, t.start_date as `task_start_date`,
t.end_date as `task_end_date`,t.parent_task_id ,ca.details
FROM tasks t
LEFT JOIN course_activities ca ON t.activity_id = ca.activity_id
LEFT JOIN categories cat ON cat.category_id = ca.category_id
WHERE t.task_status='assigned';


CREATE TABLE `keys` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`user_id` INT(11) NOT NULL,
	`key` VARCHAR(40) NOT NULL,
	`level` INT(2) NOT NULL,
	`ignore_limits` TINYINT(1) NOT NULL DEFAULT '0',
	`is_private_key` TINYINT(1) NOT NULL DEFAULT '0',
	`ip_addresses` TEXT NULL,
	`date_created` DATETIME NOT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=1;

INSERT INTO `keys` (`id`, `user_id`, `key`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`) VALUES (1, 0, 'nielsen@1234', 0, 0, 0, NULL, '2017-10-12 13:34:33');



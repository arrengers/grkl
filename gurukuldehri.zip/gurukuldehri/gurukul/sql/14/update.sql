-- Dumping database structure for arvr_training
CREATE DATABASE IF NOT EXISTS `arvr_training` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `arvr_training`;

-- Dumping structure for table arvr_training.user_roles
CREATE TABLE IF NOT EXISTS `user_roles` (
  `user_id` varchar(64) NOT NULL,
  `role` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT IGNORE INTO `user_roles` (`user_id`, `role`) VALUES
	('avinash55', 'trainer'),
	('mahesh55', 'admin');

CREATE TABLE IF NOT EXISTS `user_roles_access` (
  `role` varchar(64) NOT NULL,
  `menu` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT IGNORE INTO `user_roles_access` (`role`, `menu`) VALUES
	('trainer', 'Tasks'),
	('trainer', 'Activities'),
	('admin', 'Tasks'),
	('admin', 'Courses'),
	('admin', 'Activities'),
	('admin', 'Categories');

ALTER TABLE `tasks`
MODIFY `task_status` enum('assigned','in progress','in review','completed','cancelled') NOT NULL;
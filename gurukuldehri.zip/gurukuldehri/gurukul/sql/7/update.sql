DROP VIEW IF EXISTS `task_lists`;
CREATE VIEW task_lists as SELECT `t`.`user_id` AS `user_id`,`t`.`activity_id` AS `activity_id`,`ca`.`activity_name` AS `activity_name`,
`ca`.`type` AS `activity_type`,`cat`.`category_name` AS `course_category`,`t`.`task_id` AS `task_id`,
`t`.`start_date` AS `task_start_date`,`t`.`end_date` AS `task_end_date`,`t`.`parent_task_id` AS `parent_task_id`,
`ca`.`details` AS `details`,`t`.`task_status` AS `task_status`, ca2.activity_id as parent_activity_id, 
ca2.activity_name as parent_task_name
FROM `tasks` `t`
LEFT JOIN `course_activities` `ca` ON `t`.`activity_id` = `ca`.`activity_id`
LEFT JOIN `categories` `cat` ON `cat`.`category_id` = `ca`.`category_id`
LEFT JOIN `tasks` `t2` ON ( (`t2`.task_id = t.parent_task_id) AND (t.parent_task_id!=''))
LEFT JOIN `course_activities` `ca2` ON (ca2.activity_id = t2.activity_id)
WHERE `t`.`task_status` = 'assigned'
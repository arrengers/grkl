DROP VIEW IF EXISTS `activity_details`;
CREATE VIEW activity_details as SELECT `ca`.`activity_id` AS `activity_id`,`ca`.`activity_name` AS `activity_name`,
`ca`.`type` AS `type`,`cat`.`category_id` AS `category_id`,`cat`.`category_name` AS `category_name`,`co`.`course_id` AS `course_id`,`co`.`course_name` AS `course_name`,`ca`.`details` AS `details`, ca.activity_status as `activity_status`
FROM `course_activities` `ca`
LEFT JOIN `categories` `cat` ON `cat`.`category_id` = `ca`.`category_id`
LEFT JOIN `courses` `co` ON (co.course_id = ca.course_id)
ALTER TABLE `users`
	ADD COLUMN `password` VARCHAR(100) NOT NULL AFTER `user_name`;

ALTER TABLE `users`
	ADD COLUMN `last_login` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `password`;

UPDATE `arvr_training`.`users` SET `password`='f3f6973d6efe09f4a6d94bec4026de5769c0d46b' WHERE  `user_id`='avinash55';
UPDATE `arvr_training`.`users` SET `password`='f3f6973d6efe09f4a6d94bec4026de5769c0d46b' WHERE  `user_id`='vinod55';
DROP TABLE IF EXISTS `users_authentication`;
CREATE TABLE `users_authentication` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expired_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `users_authentication`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users_authentication`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

DROP VIEW IF EXISTS `task_lists`;
CREATE VIEW task_lists as SELECT `t`.`user_id` AS `user_id`,`t`.`activity_id` AS `activity_id`,`ca`.`activity_name` AS `activity_name`,
`ca`.`type` AS `activity_type`,`cat`.`category_name` AS `course_category`,`t`.`task_id` AS `task_id`,
`t`.`start_date` AS `task_start_date`,`t`.`end_date` AS `task_end_date`,`t`.`parent_task_id` AS `parent_task_id`,
`ca`.`details` AS `details`,`t`.`task_status` AS `task_status`
FROM ((`tasks` `t`
LEFT JOIN `course_activities` `ca` ON((`t`.`activity_id` = `ca`.`activity_id`)))
LEFT JOIN `categories` `cat` ON((`cat`.`category_id` = `ca`.`category_id`)))
WHERE (`t`.`task_status` = 'assigned');


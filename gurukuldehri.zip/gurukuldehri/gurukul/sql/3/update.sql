DROP VIEW IF EXISTS `task_lists`;
CREATE VIEW task_lists as SELECT `t`.`activity_id` AS `activity_id`,`ca`.`activity_name` AS `activity_name`,`ca`.`type` AS `activity_type`,`cat`.`category_name` AS `course_category`,
`t`.`task_id` AS `task_id`,`t`.`start_date` AS `task_start_date`,`t`.`end_date` AS `task_end_date`
,`t`.`task_status` ,`t`.`parent_task_id` AS `parent_task_id`,
`ca`.`details` AS `details`
from ((`tasks` `t` 
	left join `course_activities` `ca` on((`t`.`activity_id` = `ca`.`activity_id`))) 
	left join `categories` `cat` on((`cat`.`category_id` = `ca`.`category_id`))) 
where (`t`.`task_status` = 'assigned')
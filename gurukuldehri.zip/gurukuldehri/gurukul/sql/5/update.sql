ALTER TABLE `training_files`
	ADD COLUMN `uploaded_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP;
UPDATE `arvr_training`.`training_files` SET `uploaded_date`='2017-11-13 02:30:05' WHERE  `file_id`='f551';
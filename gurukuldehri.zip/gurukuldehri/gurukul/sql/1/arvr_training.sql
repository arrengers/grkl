-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 14, 2017 at 01:31 AM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `arvr_training`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` varchar(64) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
('e1', 'eCollection'),
('l1', 'LHHT');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` varchar(64) NOT NULL,
  `course_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`) VALUES
('ec1', 'eCollection Photo Training'),
('ec2', 'eCollection 360 Video Training');

-- --------------------------------------------------------

--
-- Table structure for table `course_activities`
--

CREATE TABLE `course_activities` (
  `activity_id` varchar(64) NOT NULL COMMENT 'generate unique id from php alphanumeric',
  `activity_name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `course_id` varchar(64) NOT NULL,
  `category_id` varchar(64) NOT NULL,
  `activity_status` enum('draft','active','deactive','') NOT NULL,
  `details` json NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_activities`
--

INSERT INTO `course_activities` (`activity_id`, `activity_name`, `type`, `course_id`, `category_id`, `activity_status`, `details`) VALUES
('ca1', 'eCollection AR Photo Training', 'education', 'ec1', 'e1', 'draft', '{\"description\": {\"text\": \"Try to align shelf\"}}'),
('ca2', 'eCollection AR Photo Training', 'validation', 'ec1', 'e1', 'active', '{\"timeout\": 120, \"description\": {\"text\": \"Try to align shelf\"}, \"sample_rate\": 20}'),
('ca3', '360 Video Training', 'education', 'ec1', 'c1', 'active', '{\"video\": {\"file_id\": \"f551\", \"file_url\": \"http://arvr-load-223464067.us-east-1.elb.amazonaws.com/training_files/f551.mp4\"}, \"overlays\": [{\"norm_x\": 0.5, \"norm_y\": 0, \"end_frame\": 200, \"norm_width\": 0.2, \"norm_height\": 0.1, \"start_frame\": 100, \"content_type\": \"text\", \"content_details\": {\"text\": \"Showing this popup for information\"}}], \"description\": {\"text\": \"Play video for training\"}}');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `task_id` varchar(64) NOT NULL COMMENT 'unique id from php',
  `user_id` varchar(64) NOT NULL,
  `activity_id` varchar(64) NOT NULL,
  `start_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `parent_task_id` varchar(64) NOT NULL,
  `task_status` enum('assigned','in_progress','in_review','completed','cancelled') NOT NULL,
  `assignment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`task_id`, `user_id`, `activity_id`, `start_date`, `end_date`, `parent_task_id`, `task_status`, `assignment_date`, `updated_date`) VALUES
('t1', 'avinash55', 'ca1', '2017-11-12 00:00:00', '2017-11-30 00:00:00', '', 'assigned', '2017-11-08 00:00:00', '2017-11-13 06:31:34');

-- --------------------------------------------------------

--
-- Table structure for table `task_updates`
--

CREATE TABLE `task_updates` (
  `update_id` varchar(64) NOT NULL,
  `task_id` varchar(64) NOT NULL,
  `update_type` enum('status','chat','data_update','notification') NOT NULL,
  `content` json NOT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task_updates`
--

INSERT INTO `task_updates` (`update_id`, `task_id`, `update_type`, `content`, `updated_date`) VALUES
('ud1', 't1', 'status', '{\"assignee\": \"Avinash Kumar\", \"current_status\": \"assigned\", \"previous_status\": \"\"}', '2017-11-13 07:35:06');

-- --------------------------------------------------------

--
-- Table structure for table `training_files`
--

CREATE TABLE `training_files` (
  `file_id` varchar(64) NOT NULL,
  `file_extention` varchar(10) NOT NULL,
  `file_type` varchar(20) NOT NULL,
  `file_title` varchar(200) NOT NULL,
  `file_description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `training_files`
--

INSERT INTO `training_files` (`file_id`, `file_extention`, `file_type`, `file_title`, `file_description`) VALUES
('f551', 'mp4', '360_video', '360_0007.MP4', 'eCollection Photo Training and Barcode Scan Training');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` varchar(64) NOT NULL COMMENT 'unique id from php',
  `user_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`) VALUES
('avinash55', 'Avinash Kumar'),
('vinod55', 'Vinod Kadam');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `course_activities`
--
ALTER TABLE `course_activities`
  ADD PRIMARY KEY (`activity_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `task_updates`
--
ALTER TABLE `task_updates`
  ADD PRIMARY KEY (`update_id`);

--
-- Indexes for table `training_files`
--
ALTER TABLE `training_files`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

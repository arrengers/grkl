ALTER TABLE `training_files`
	CHANGE COLUMN `file_description` `file_description` VARCHAR(200) NULL AFTER `file_title`;
